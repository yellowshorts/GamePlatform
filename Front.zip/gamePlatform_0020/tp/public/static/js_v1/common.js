(function(){
    // 全局鼠标滚动事件
    $('.my-scrollbar-wrap').scroll(function() {

        $('.my-scrollbar-thumb').css({
            'transform': 'translateY('+($(this).scrollTop()/10)+'%)'
        });
        // 左侧导航联动效果
        $('.woBcA8qpePHUmBxmQHCw').each(function(){
            if ($(this).offset().top < 60) {
                var id = $(this)[0].id.split('-')[0];
                $('.Hm3ZQM8AN8kBWjUOWg7o').find('a').removeClass('ckjEJZxiInSIVC83ZOUd');
                $('#'+ id +'-menu').addClass('ckjEJZxiInSIVC83ZOUd');
            }
        });

        if ($(this).scrollTop() < 300) {
            $('.Hm3ZQM8AN8kBWjUOWg7o').find('a').removeClass('ckjEJZxiInSIVC83ZOUd');
            $('#hot-menu').addClass('ckjEJZxiInSIVC83ZOUd');
        }
    });
    // Header-language语言选择
    $('#header-switchLang').on('click',function(){
        if ($(this).find('.jVfUjkoNdkDoZNDJYcIi').hasClass('ant-dropdown-open')) {
            $(this).find('.jVfUjkoNdkDoZNDJYcIi').removeClass('ant-dropdown-open');
            $('#language_window').find('.ant-dropdown').hide(100);
        } else {
            $(this).find('.jVfUjkoNdkDoZNDJYcIi').addClass('ant-dropdown-open');
            $('#language_window').find('.ant-dropdown').css('left', $(this).offset().left).show(100);
        }
    });
    // header-switchCurrency 钱包选择
    $('#header-switchCurrency').on('click',function(){
        if ($(this).find('.b4gQjqmRH8tjkzGFg0E7').hasClass('ant-dropdown-open')) {
            $(this).find('.b4gQjqmRH8tjkzGFg0E7').removeClass('ant-dropdown-open');
            $('#currency_window').find('.ant-dropdown').hide(100);
        } else {
            $(this).find('.b4gQjqmRH8tjkzGFg0E7').addClass('ant-dropdown-open');
            $('#currency_window').find('.ant-dropdown').css('left', $(this).offset().left).show(100);
        }
    });
    var verification = {
        'user_name': {
            'empty': 'Digite 4-16 caracteres, letras/números são suportados',
        },
        'password': {
            'empty': '6-16 caracteres, incluindo pelo menos duas letras/números/símbolos',
        },
        'register-user_name': {
            'empty': 'Digite 4-16 caracteres, letras/números são suportados',
        },
        'register-password': {
            'empty': '6-16 caracteres, incluindo pelo menos duas letras/números/símbolos',
        },
        'register-password_re': {
            'empty': '6-16 caracteres, incluindo pelo menos duas letras/números/símbolos',
            'confirm': 'The passwords do not match. Please re-enter.',
        },
        'btnIcon': '<i aria-label="icon: loading" class="anticon anticon-loading"><svg viewBox="0 0 1024 1024" data-icon="loading" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false" class="anticon-spin"><path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 0 0-94.3-139.9 437.71 437.71 0 0 0-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z"></path></svg></i>',
        'password-eye-hide': '<i aria-label="icon: eye-invisible" tabindex="-1" class="anticon anticon-eye-invisible ant-input-password-icon"><i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 21.514" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image/sprite.e843f4edc123f4430822.svg#comm_icon_hide--sprite"></use></svg></i></i>',
        'password-eye-show': '<i aria-label="icon: eye" tabindex="-1" class="anticon anticon-eye ant-input-password-icon"><i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 17.776" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image/sprite.e843f4edc123f4430822.svg#comm_icon_show--sprite"></use></svg></i></i>',
    };
    // Login 登录验证
    $(document).on('blur', '#user_name,#password', function(e){
        var id = e.target.id;
        checkVerificationCall(id);
    });
    // Register 注册验证
    $(document).on('blur', '#register-user_name,#register-password,#register-password_re', function(e){
        var id = e.target.id;
        checkVerificationCall(id);
    });
    // Login登录
    $('#submitLogin').on('click',function(){
        var user_name = checkVerificationCall('user_name');
        var password  = checkVerificationCall('password');
        if (!user_name || !password) {
            return false;
        }
        $(this).addClass('ant-btn-loading').prepend(verification['btnIcon']);
    });

    // Register注册
    $('#submitRegister').on('click',function(){
        var user_name = checkVerificationCall('register-user_name');
        var password  = checkVerificationCall('register-password');
        var password_re  = checkVerificationCall('register-password_re');
        if (!user_name || !password || !password_re) {
            return false;
        }
        var data = {
            user_name: $('#register-user_name').val(),
            password: $('#register-password').val(),
            confirm_password: $('#register-password_re').val()
        };

        $(this).addClass('ant-btn-loading').prepend(verification['btnIcon']);
        var _this = $(this);

        $.post('/api/register/register?lang='+$.cookie('language'),data,function(data){
            if (data.status == 0) {
                location.reload();
            } else {
                Qmsg.error(data.message);
                _this.removeClass('ant-btn-loading').find('.anticon-loading').remove();
            }
        },'json');
    });
    // 密码眼睛
    $('.ant-input-suffix').on('click', function(){
       var eye_status = $(this).prev()[0]['type'] == 'password' ? 'show' : 'hide';
       var eye_html = verification['password-eye-'+eye_status];
       if (eye_status == 'show') {
         $(this).prev().attr('type','text');
       } else {
         $(this).prev().attr('type','password');
       }
       $(this).html(eye_html);

    });
    // 弹出窗口关闭
    $('.ant-modal-close').on('click',function(){
        $(this).parent().parent().parent().parent().parent().hide();
    });
    // 登录注册窗口打开
    $(document).on('click', '#open-register, #open-login', function(e){
        var id = e.target.id;
        alert(9090)
        if (id == 'open-login') {
            $('#login_window').show();
        }
        if (id == 'open-register') {
            $('#register_window').show();
        }
    });
    // 登录注册按钮切换
    $(document).on('click', '.register-open, .login-open', function(e){
        if ($(this).hasClass('login-open')) {
            $('#register_window').hide();
            $('#login_window').show();
        }
        if ($(this).hasClass('register-open')) {
            $('#login_window').hide();
            $('#register_window').show();
        }
    });
    // 验证共有方法
    function checkVerificationCall(id) {
        var value = $('#'+ id).val();
        // 登录
        if (id == 'user_name') {
            if (!value || value.length < 4 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'password') {
            if (!value || value.length < 6 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        // 注册
        if (id == 'register-user_name') {
            if (!value || value.length < 4 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'register-password') {
            if (!value || value.length < 6 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'register-password_re') {
            if (!value || value.length < 6 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            if (value != $('#register-password').val()) {
                return checkVerification(id, 'confirm', 'error');
            }
            return checkVerification(id, '', 'success');
        }
    }
    function checkVerification(id, error_type, type) {
        var el = $('#'+ id);
        if (type == 'error') {
            el.parents('.ant-form-item-control').addClass('has-error').find('.ant-form-explain').text(verification[id][error_type]).show(100);
            return false;
        }
        if (type == 'success') {
            el.parents('.ant-form-item-control').removeClass('has-error').find('.ant-form-explain').text('').hide();
        }
        return true;
    }
})();