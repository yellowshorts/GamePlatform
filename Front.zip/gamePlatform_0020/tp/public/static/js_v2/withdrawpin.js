var pincode = {
    'pincode-password': {
        showType: 0,
        passwordLength: 0,
        passwordText: '',
    },
    'pincode-password-confirm': {
        showType: 0,
        passwordLength: 0,
        passwordText: '',
    },
    showTypeIcon: ['<i class="M2AXg2u2tA9h8un7RCbH" style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 21.514" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.b356098cf3d4227ddef6.svg#comm_icon_hide--sprite"></use></svg></i>','<i class="MOFLcj7nVRZHKLivuWpP" style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 17.776" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.b356098cf3d4227ddef6.svg#comm_icon_show--sprite"></use></svg></i>'],
    showTypeText: ['<i></i>','<span class="number-input__text"></span>'],
};
// 密文明文调整
$('#pincode-password').add('#pincode-password-confirm').on('click', function(e){
    var id = $(this)[0].id;
    if (pincode[id].showType == 0) {
        pincode[id].showType = 1;
    } else {
        pincode[id].showType = 0;
    }
    $(this).html(pincode.showTypeIcon[pincode[id].showType]);
    // 更改文字明文
    if (pincode[id].showType == 1) {
        // 密码输入
        if (id == 'pincode-password') {
            $('#pincode-password-info').find('li').html(pincode['showTypeText'][1]);
            var code = [...$('#pincode-input-password').val()];
            for (var i = 0; i < code.length; i++) {
                $('#pincode-password-info').find('li').eq(i).find('.number-input__text').html(code[i]);
            }
        }
        if (id == 'pincode-password-confirm') {
            $('#pincode-password-confirm-info').find('li').html(pincode['showTypeText'][1]);
            var code = [...$('#pincode-input-confirm-password').val()];
            for (var i = 0; i < code.length; i++) {
                $('#pincode-password-confirm-info').find('li').eq(i).find('.number-input__text').html(code[i]);
            }
        }
    } else {
        if (id == 'pincode-password') {
            $('#pincode-password-info').find('li').html(pincode['showTypeText'][0]);
        }
        if (id == 'pincode-password-confirm') {
            $('#pincode-password-confirm-info').find('li').html(pincode['showTypeText'][0]);
        }
    }
});
$('#pincode-password-info').on('click',function(){
    if (pincode['pincode-password']['passwordLength'] == 6) {
        var index = 5;
    } else {
        var index = pincode['pincode-password']['passwordLength'];
    }
    $(this).find('li').removeClass('qywCxukpVNuYyPfI4XVq').each(function(){
        if ($(this).index() == index) {
            $(this).addClass('qywCxukpVNuYyPfI4XVq');
            $('#pincode-input-password').focus();
        }
    });
});
$('#pincode-password-confirm-info').on('click', function(){
    if (pincode['pincode-password-confirm']['passwordLength'] == 6) {
        var index = 5;
    } else {
        var index = pincode['pincode-password-confirm']['passwordLength'];
    }
    $(this).find('li').removeClass('qywCxukpVNuYyPfI4XVq').each(function(){
        if ($(this).index() == index) {
            $(this).addClass('qywCxukpVNuYyPfI4XVq');
            $('#pincode-input-confirm-password').focus();
        }
    });
});
$('#pincode-input-password').on('keyup blur', function(e){
    if (e.keyCode == 8 && $(this).val().length < pincode['pincode-password'].passwordLength) {
        if (pincode['pincode-password'].passwordLength == 0) {
            return;
        }
        pincode['pincode-password'].passwordLength -= 1;
        $('#pincode-password-info').click();
        $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength).removeClass('mzfnT1F3zRDTZOXCiEGs');
        if (pincode['pincode-password'].showType == 1) {
            $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength).find('span').html('');
        }
    }
    if (e.type == 'blur' || e.type == 'keyup') {
        if ($(this).val().length < 6 && $(this).parent().parent().next().css('display') == 'none') {
            $(this).parent().parent().next().show(100);
        }
        if ($(this).val().length >= 6) {
            $(this).parent().parent().next().hide();
        }
    }
    var regexp = /[^\d]/g;
    $(this).val($(this).val().replace(regexp, ''));
    if (regexp.test($(this).val()) || $(this).val().length == pincode['pincode-password'].passwordLength) {
        return;
    }
    pincode['pincode-password'].passwordLength += 1;
    $('#pincode-password-info').click();
    $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength-1).addClass('mzfnT1F3zRDTZOXCiEGs');
    if (pincode['pincode-password'].showType == 1) {
        $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength-1).find('span').html($(this).val()[pincode['pincode-password'].passwordLength-1]);
    }
});
$('#pincode-input-confirm-password').on('keyup blur', function(e){
    if (e.keyCode == 8 && $(this).val().length < pincode['pincode-password-confirm'].passwordLength) {
        if (pincode['pincode-password-confirm'].passwordLength == 0) {
            return;
        }
        pincode['pincode-password-confirm'].passwordLength -= 1;
        $('#pincode-password-confirm-info').click();
        $('#pincode-password-confirm-info').find('li').eq(pincode['pincode-password-confirm'].passwordLength).removeClass('mzfnT1F3zRDTZOXCiEGs');
        if (pincode['pincode-password-confirm'].showType == 1) {
            $('#pincode-password-confirm-info').find('li').eq(pincode['pincode-password-confirm'].passwordLength).find('span').html('');
        }
    }
    if (e.type == 'blur' || e.type == 'keyup') {
        if ($(this).val().length < 6 && $(this).parent().parent().next().css('display') == 'none') {
            $(this).parent().parent().next().show(100);
        }
        if ($(this).val().length >= 6) {
            $(this).parent().parent().next().hide();
        }
    }
    var regexp = /[^\d]/g;
    $(this).val($(this).val().replace(regexp, ''));
    if (regexp.test($(this).val()) || $(this).val().length == pincode['pincode-password-confirm'].passwordLength) {
        return;
    }
    pincode['pincode-password-confirm'].passwordLength += 1;
    $('#pincode-password-confirm-info').click();
    $('#pincode-password-confirm-info').find('li').eq(pincode['pincode-password-confirm'].passwordLength-1).addClass('mzfnT1F3zRDTZOXCiEGs');
    if (pincode['pincode-password-confirm'].showType == 1) {
        $('#pincode-password-confirm-info').find('li').eq(pincode['pincode-password-confirm'].passwordLength-1).find('span').html($(this).val()[pincode['pincode-password-confirm'].passwordLength-1]);
    }
});
$('#setwithdrawpin').on('click', function(){

    var pincode = $('#pincode-input-password').val();
    var pincodeConfirm = $('#pincode-input-confirm-password').val();
    var pincodeEl =  $('#pincode_error');
    var pincodeconfirmEl = $('#pincode_confirm_error');

    if (!pincode) {
        pincodeEl.text('Withdraw PIN Field cannot be empty').show();
        return;
    }
    if (pincode.length < 6) {
        pincodeEl.text(withdrawPinCode.length).show();
        return;
    }
    if (!pincodeConfirm) {
        pincodeconfirmEl.text(withdrawPinCode.empty).show();
        return;
    }
    if (pincodeConfirm < 6) {
        pincodeconfirmEl.text(withdrawPinCode.length).show();
        return;
    }
    if (pincode !== pincodeConfirm) {
        pincodeconfirmEl.text(withdrawPinCode.confirmPassword).show();
        return;
    }

    pincodeEl.hide();
    pincodeconfirmEl.hide();

    $(this).addClass('ant-btn-loading').prepend(window.verification['btnIcon']);

    $.post('/api/withdraw/savePinCode',{pincode:pincode}, function(data){
        if (data.status == 0) {
            Qmsg.success(data.message);
            setTimeout(function(){
                if (isMobile()) {
                    location.href = '/mobile/Saque';
                } else {
                    location.href = '/index/Withdraw';
                }
            },3000)
        } else {
            Qmsg.error(data.message);
        }
    },'Json');
});


function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}