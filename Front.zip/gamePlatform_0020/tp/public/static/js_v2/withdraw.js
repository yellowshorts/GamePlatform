(function(){
     // 代付金额输入
     $('#withdraw_pix_money').on('input blur', function(e){
        $(this).val($(this).val().replace(/[^\d]/g, '')*1);
        if ($(this).attr('data-brl_wallet')*1 < $(this).val()*1) {
            $(this).val(0);
        }
        if (e.type == 'blur') {
            if (!$(this).val() || $(this).val() == 0) {
                $(this).parent().parent().next().show(200);
                return;
            }
            $(this).parent().parent().next().hide();
        }
    });
    // All IN
    $('#allin').on('click', function(e){
        e.stopPropagation();
        $(this).parent().prev().val($(this).parent().prev().attr('data-brl_wallet'));
        return false;
    });
    // 提现页面 选择账户
    $('#select_account').on('click', function(e){
        e.stopPropagation();
        if ($(this).hasClass('ant-select-open')) {
            $(this).removeClass('ant-select-open');
            $('#'+ $(this)[0].id + '_window').hide();
            return;
        }
        $(this).addClass('ant-select-open');
        var id = $(this).find('.ant-select-selection-selected-value').attr('data-id');
        $('#'+ $(this)[0].id + '_window').css('left', $(this).offset().left).css('top', $(this).offset().top + 50).show(200).find('li').removeClass('ant-select-dropdown-menu-item-selected').each(function(){
            if ($(this).attr('data-id') == id) {
                $(this).addClass('ant-select-dropdown-menu-item-selected');
            }
        });
    });
    // 提现页面 选择账户
    $('#select_account_window .ant-select-dropdown-menu').on('click', 'li', function(e){
        e.stopPropagation();
        var account_number = $.trim($(this).find('.account_number_span').attr('data-account_number'));
        var account_type = $.trim($(this).find('.account_type_span').attr('data-account_type'));
        var id = $(this).attr('data-id');
        $('#select_account').find('.ant-select-selection-selected-value').attr('data-id', id).find('.account_number_span').attr('data-account_number', account_number).text('('+account_number+')').next().attr('data-account_type', account_type).text(account_type);
        $('#select_account').click();
    });
    // 提现页面 导航切换Tab
    $('#listUlId').on('click','li', function(){
        var id = $(this).attr('data-id');
        if ($(this).hasClass('tavNREqvslKfnyAQiSMs')) {
            return;
        }
        $(this).parent().find('li').removeClass('tavNREqvslKfnyAQiSMs').each(function(){
            var all = $(this).attr('data-id');
            $('#'+all).hide();
            $('#'+all+'_title').hide();
        });
        $(this).addClass('tavNREqvslKfnyAQiSMs');
        $('#'+id).show();
        $('#'+id+'_title').show();
        // console.log(id);
    });
    
    // 选择默认账户 及 添加账户
    $('#pix_list').on('click','li',function(e){
        // 添加账户
        if ($(this).hasClass('ADDPIX')) {
            $('#withdraw_window').show(100);
            return;
        }
        // 默认账户类型选择
        var id = $(this).attr('data-id');
        if ($(this).hasClass('Tnmaq_ADd9neNz1uCT_1')) {
            return;
        }
        $(this).parent().find('li').removeClass('Tnmaq_ADd9neNz1uCT_1').find('.bt8Qm2mbpyp1pxsxoxK2').hide().next().hide();
        $(this).addClass('Tnmaq_ADd9neNz1uCT_1').find('.bt8Qm2mbpyp1pxsxoxK2').show().next().show();
        $.post('/api/withdraw/default', {id:id}, function(data){
            if (data.status != 0) {
                Qmsg.error(data.message);
            }
        },'Json');
    });
    // 选择账户
    $('#select_account_type').on('click', function(e){
        e.stopPropagation();
        if ($(this).hasClass('ant-select-open')) {
            $(this).removeClass('ant-select-open ant-select-focused');
            $('#account_type').hide(100);
            return;
        }
        $(this).addClass('ant-select-open ant-select-focused');
        $('#account_type').css({'left': $(this).offset().left, 'top': $(this).offset().top + 50}).show(100);
        var accountType =  $.trim($(this).find('.ant-select-selection__rendered').find('.ant-select-selection-selected-value').text());
        if (accountType) {
            $('#account_list').find('li').removeClass('ant-select-dropdown-menu-item-selected').each(function(){
                if ($.trim($(this).text()) == accountType) {
                    $(this).addClass('ant-select-dropdown-menu-item-selected');
                }
            });
        }
    });
    // 关闭账户类型弹窗
    $('#withdraw_window').on('click', function(e){
        e.stopPropagation();
        $('#select_account_type').removeClass('ant-select-open ant-select-focused');
        $('#account_type').hide(100);
    });
    // 账户选择
    $('#account_list').on('click', 'li', function(){
        var accountType = $.trim($(this).text());
        $('#withdraw_window').find('.ant-select-selection__rendered').find('.ant-select-selection-selected-value').text(accountType);
        $('#select_account_type').click();
        $('#withdraw_window').find('#select_account_type').parent().parent().parent().removeClass('has-error').find('.ant-form-explain').text('')
    });
    // 账户失去焦点验证
    $('#pix_account').add('#cpf_number').on('blur', function(){
        var id = $(this)[0].id;
        if (!$(this).val()) {
            $(this).parent().parent().parent().addClass('has-error').find('.ant-form-explain').text(pixverify[id]['empty']);
            return;
        }
        $(this).parent().parent().parent().removeClass('has-error').find('.ant-form-explain').text('');
    });
    // 账户提交验证
    $('#account_submit').on('click', function(){
        var withdraw_window = $(this).parents('#withdraw_window');
        var data = {};
            data.account_type = $.trim(withdraw_window.find('.ant-select-selection__rendered').find('.ant-select-selection-selected-value').text());
            data.pix_account = withdraw_window.find('#pix_account').val();
            data.cpf_account = withdraw_window.find('#cpf_number').val();
        var flag = true;
        if (!data.account_type) {
            withdraw_window.find('#select_account_type').parent().parent().parent().addClass('has-error').find('.ant-form-explain').text(pixverify['account_type']['empty']);
            flag = false;
        }
        if (!data.pix_account) {
            $('#pix_account').blur();
            flag = false;
        }
        if (!data.cpf_account) {
            $('#cpf_number').blur();
            flag = false;
        }

        if (flag) {
            $(this).addClass('ant-btn-loading').prepend(pixverify['btnIcon']);
            var _this = $(this);
            $.post('/api/withdraw/saveWithdrawInfo', data, function(data){
                if (data.status == 0) {
                    location.reload();
                } else {
                    Qmsg.error(data.message);
                    _this.removeClass('ant-btn-loading').find('.anticon-loading').remove();
                }
            },'Json');
        }
    });
    // pinCode
    var pincode = {
        'pincode-password': {
            showType: 0,
            passwordLength: 0,
            passwordText: '',
        },
        showTypeIcon: ['<i class="M2AXg2u2tA9h8un7RCbH" style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 21.514" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.b356098cf3d4227ddef6.svg#comm_icon_hide--sprite"></use></svg></i>','<i class="MOFLcj7nVRZHKLivuWpP" style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 17.776" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.b356098cf3d4227ddef6.svg#comm_icon_show--sprite"></use></svg></i>'],
        showTypeText: ['<i></i>','<span class="number-input__text"></span>'],
    };
    // 密文明文调整
    $('#pincode-password').on('click', function(e){
        var id = $(this)[0].id;
        if (pincode[id].showType == 0) {
            pincode[id].showType = 1;
        } else {
            pincode[id].showType = 0;
        }
        $(this).html(pincode.showTypeIcon[pincode[id].showType]);
        // 更改文字明文
        if (pincode[id].showType == 1) {
            // 密码输入
            if (id == 'pincode-password') {
                $('#pincode-password-info').find('li').html(pincode['showTypeText'][1]);
                var code = [...$('#pincode-input-password').val()];
                for (var i = 0; i < code.length; i++) {
                    $('#pincode-password-info').find('li').eq(i).find('.number-input__text').html(code[i]);
                }
            }
        } else {
            if (id == 'pincode-password') {
                $('#pincode-password-info').find('li').html(pincode['showTypeText'][0]);
            }
        }
    });
    $('#pincode-password-info').on('click',function(){
        if (pincode['pincode-password']['passwordLength'] == 6) {
            var index = 5;
        } else {
            var index = pincode['pincode-password']['passwordLength'];
        }
        $(this).find('li').removeClass('qywCxukpVNuYyPfI4XVq').each(function(){
            if ($(this).index() == index) {
                $(this).addClass('qywCxukpVNuYyPfI4XVq');
                $('#pincode-input-password').focus();
            }
        });
    });
    $('#pincode-input-password').on('keyup blur', function(e){
        if (e.keyCode == 8 && $(this).val().length < pincode['pincode-password'].passwordLength) {
            if (pincode['pincode-password'].passwordLength == 0) {
                return;
            }
            pincode['pincode-password'].passwordLength -= 1;
            $('#pincode-password-info').click();
            $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength).removeClass('mzfnT1F3zRDTZOXCiEGs');
            if (pincode['pincode-password'].showType == 1) {
                $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength).find('span').html('');
            }
        }
        if (e.type == 'blur' || e.type == 'keyup') {
            if ($(this).val().length < 6 && $(this).parent().parent().next().css('display') == 'none') {
                $(this).parent().parent().next().show(100);
            }
            if ($(this).val().length >= 6) {
                $(this).parent().parent().next().hide();
            }
        }
        var regexp = /[^\d]/g;
        $(this).val($(this).val().replace(regexp, ''));
        if (regexp.test($(this).val()) || $(this).val().length == pincode['pincode-password'].passwordLength) {
            return;
        }
        pincode['pincode-password'].passwordLength += 1;
        $('#pincode-password-info').click();
        $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength-1).addClass('mzfnT1F3zRDTZOXCiEGs');
        if (pincode['pincode-password'].showType == 1) {
            $('#pincode-password-info').find('li').eq(pincode['pincode-password'].passwordLength-1).find('span').html($(this).val()[pincode['pincode-password'].passwordLength-1]);
        }
    });

    $('#submit-withdraw').on('click', function(){
        var data = {};
            data.money = $('#withdraw_pix_money').val();
            data.account_id = $('#select_account').find('.ant-select-selection-selected-value').attr('data-id');
            data.pin_code = $('#pincode-input-password').val();
            data.type = 'withdrawal';
        if (!(data.money*1)) {
            $('#withdraw_pix_money').blur();
            return;
        }
        if (!data.pin_code) {
            $('#pincode_error').text('Withdraw PIN Field cannot be empty').show();
            return;
        }
        if (data.pin_code.length < 6) {
            $('#pincode_error').text('6 numbers').show();
            return;
        }
        $(this).addClass('ant-btn-loading').prepend(pixverify['btnIcon']);
        var _this = $(this);
        $.post('/api/Pay', data, function(data){
            if (data.status == 0) {
                Qmsg.success(data.message);
                setTimeout(function(){
                    location.reload();
                }, 3000);
			} else {
                if (data.status == 2) {
                    $('#withdrawLimit_window').find('#withdrawBlanace').text('R$ '+data.result.brl_wallet).end().find('#bettingBlanace').text(data.result.coding_blanace).end().show();
                } else {
                    Qmsg.error(data.message);
                }
                _this.removeClass('ant-btn-loading').find('.anticon-loading').remove();
            }
        }, 'Json');
    });

    $('#setwithdrawpin').on('click', function(){
    
        var pincode = $('#pincode-input-password').val();
        var pincodeConfirm = $('#pincode-input-confirm-password').val();
        var pincodeEl =  $('#pincode_error');
        var pincodeconfirmEl = $('#pincode_confirm_error');
    
        if (!pincode) {
            pincodeEl.text('Withdraw PIN Field cannot be empty').show();
            return;
        }
        if (pincode.length < 6) {
            pincodeEl.text('6 numbers').show();
            return;
        }
        if (!pincodeConfirm) {
            pincodeconfirmEl.text('Withdraw PIN Field cannot be empty').show();
            return;
        }
        if (pincodeConfirm < 6) {
            pincodeconfirmEl.text('6 numbers').show();
            return;
        }
        if (pincode !== pincodeConfirm) {
            pincodeconfirmEl.text('The passwords do not match. Please re-enter.').show();
            return;
        }
    
        pincodeEl.hide();
        pincodeconfirmEl.hide();
    
        $(this).addClass('ant-btn-loading').prepend(window.verification['btnIcon']);
    
        $.post('/api/withdraw/savePinCode',{pincode:pincode}, function(data){
            if (data.status == 0) {
                Qmsg.success(data.message);
            } else {
                Qmsg.error(data.message);
            }
        },'Json');
    });
})();

//ant-select-dropdown-menu-item-selected