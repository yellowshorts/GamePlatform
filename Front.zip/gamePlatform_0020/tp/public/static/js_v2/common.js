// (function(){
$(document).ready(function(){
    // 全局点击关闭弹窗
    $(document).on('click', function(e){
       if ($('#nav_language').hasClass('ant-popover-open')) {
           $('#nav_language').click();
       }
       if ($('#header-switchLang').find('.jVfUjkoNdkDoZNDJYcIi').hasClass('ant-dropdown-open')) {
           $('#header-switchLang').click();
       }
       if ($('#header-switchCurrency').find('.b4gQjqmRH8tjkzGFg0E7').hasClass('ant-dropdown-open')) {
           $('#header-switchCurrency').click();
       }
       if ($('#open_wallet').hasClass('ant-select-open')) {
           $('#open_wallet').click();
       }
       if ($('#pay_des_info').css('display') == 'block') {
            $('#pay_des_info').hide();
       }
       if ($('#select_account').hasClass('ant-select-open')) {
            $('#select_account_window').hide();
            $('#select_account').removeClass('ant-select-open');
       }
       if ($('#logList').css('display') == 'block') {
            $('#logList').hide(200);
       }
    });
    // 钱包余额
    $('.NKLcc8z9N8zQBqlEQHzQ').on('click', function(){
        if ($(this).hasClass('animate__animated')) {
            return;
        }
        $(this).addClass('animate__animated');
        var _this = $(this);
        $.post('/api/Aupay/getAmount',{},function(rs){
           _this.prev().find('.SSAbrhtT3U690CrzLUd5').text('R$ '+ rs.result);
           setTimeout(function(){
                _this.removeClass('animate__animated');
           },1000)
        },'Json');
    });
    // 提现跳转
    $('#withdraw').on('click', function(){
        location.href = '/index/withdraw';
    });
    // 支付窗口
    $('#payment').on('click', function(e){
        $('#payment_window').show();
    });
    // 切换支付
    $('.CJ8dBGR3Ac2Lugo_wuSA').on('click','li', function(){
        if ($(this).hasClass('tivA24cSEjfykc3h2PmN')) {
            return;
        }
        $(this).parent().find('li').removeClass('tivA24cSEjfykc3h2PmN');
        $(this).addClass('tivA24cSEjfykc3h2PmN');
    });
    // 支付选择金额
    $('#select_pix').on('click', 'li', function(){
        if ($(this).hasClass('tivA24cSEjfykc3h2PmN')) {
            return;
        }
        var money = $.trim($(this).find('.money').text());
        $('#pix_money').val(money);
        var p_html = '<p class="_ojhUxKWGyFdJIV2Lodx subscript"><i class="orcE9bnrEF9xDTLnxVZg gou" style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 20 15" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.b356098cf3d4227ddef6.svg#comm_icon_gou--sprite"></use></svg></i><i class="ZmbOmk0ieSKOdeIimJCA bg" style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 28 28" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.b356098cf3d4227ddef6.svg#comm_img_corner--sprite"></use></svg></i></p>';
        $(this).parent().find('li').removeClass('tivA24cSEjfykc3h2PmN').find('._ojhUxKWGyFdJIV2Lodx').remove().end().end().end().addClass('tivA24cSEjfykc3h2PmN').find('.money').append(p_html);
    });
    // 支付金额输入
    $('#pix_money').on('input', function(){
        $(this).val($(this).val().replace(/[^\d]/g, ''));
    });
    // 支付描述
    $(document).on('click','#pay_des',function(e){
        e.stopPropagation();
        var pay_des_info = $('#pay_des_info');
        pay_des_info.css('left', $(this).offset().left - pay_des_info.width() + 160).css('top', $(this).offset().top - pay_des_info.height() - 10).show(100);
    });
    // 提交支付
	$('.deposit-submit-button').on('click',function(){
        var _this = $(this);
        var pay_name = $('.CJ8dBGR3Ac2Lugo_wuSA').find('.tivA24cSEjfykc3h2PmN').attr('data-pay_name');
		var data = {'gift_id':0, 'type': 'payment', 'pay_name': pay_name};
        $('.ceiktj0nGFZYA3JZ65zu').find('li').each(function(){
            if ($(this).hasClass('tivA24cSEjfykc3h2PmN')) {
                data.gift_id = $(this).attr('data-gift_id');
            }
        });
        if (!data.gift_id) {
            Qmsg.error('Por favor seleccione a quantidade de recharge');
            return;
        }

        $(this).addClass('ant-btn-loading').prepend(verification['btnIcon']);
		$.post('/api/Pay',data,function(data){
			if (data.status == 0) {
				window.open(data.result.url);
				payAjaxpolling(data.result.order_no);
			} else {
                Qmsg.error(data.message);
			}
			_this.removeClass('ant-btn-loading').find('.anticon-loading').remove();
		},'json');
	});
    // 开启轮训
	function payAjaxpolling(transaction_id) {
		setInterval(function(){
			$.post('/api/Aupay/checkPayStatus',{transaction_id:transaction_id},function(data){
				if (data.result > 0) {
					location.reload();
				}
			},'Json');
		},3000);
	}
    // 注册打开钱包
    $('#open_wallet').on('click', function(e){
       e.stopPropagation();
       if ($(this).hasClass('ant-select-open')) {
           $('#register_wallet').hide(100);
           $(this).removeClass('ant-select-open');
       } else {
           $(this).addClass('ant-select-open');
           var selectedValue = $.trim($(this).find('.ant-select-selection__rendered').find('span').text());
           if (selectedValue) {
               $('#register_wallet').find('li').each(function(){
                   $(this).removeClass('ant-select-dropdown-menu-item-selected');
                   if (selectedValue == $.trim($(this).find('span').text())) {
                       $(this).addClass('ant-select-dropdown-menu-item-selected');
                   }
               });
           }
           $('#register_wallet').css({'left': $(this).offset().left,'top': $(this).offset().top + 40}).show(100);
       }
    });
    // 注册选择钱包
    var wallet_name = ''; 
    $('#register_wallet').on('click', 'li', function(){
       var text = $.trim($(this).find('span').text());
       wallet_name = $(this).find('span').attr('data-wallet');
       var icon = $(this).find('.anticon').html();
       $('#open_wallet').find('.ant-select-selection__rendered').find('.anticon').html(icon).next().text(text)
       .parent().parent().parent().prev().removeClass('ant-select-selection__placeholder');
    });
    // Header-language语言选择
   $('#header-switchLang').on('click',function(e){
       e.stopPropagation();
       if ($(this).find('.jVfUjkoNdkDoZNDJYcIi').hasClass('ant-dropdown-open')) {
           $(this).find('.jVfUjkoNdkDoZNDJYcIi').removeClass('ant-dropdown-open');
           $('#language_window').find('.ant-dropdown').hide(100);
       } else {
           $(this).find('.jVfUjkoNdkDoZNDJYcIi').addClass('ant-dropdown-open');
           $('#language_window').find('.ant-dropdown').css('left', $(this).offset().left).show(100);
       }
   });
   // Nav-language语言选择
   $('#nav_language').on('click',function(e){
       e.stopPropagation();
       if ($(this).hasClass('ant-popover-open')) {
           $(this).removeClass('ant-popover-open');
           $('#window_nav_language').find('.pvnU4HFzocTeDDufM0jI').hide(100);
       } else {
           $(this).addClass('ant-popover-open');
           $('#window_nav_language').find('.pvnU4HFzocTeDDufM0jI').css('top', $(this).offset().top).css('left',  $('.H1qIcLMTDnWg35ewI9bx').width() - 15).show(100);
       }
   });
   // header-switchCurrency 钱包选择
   $('#header-switchCurrency').on('click',function(e){
       e.stopPropagation();
       if ($(this).find('.b4gQjqmRH8tjkzGFg0E7').hasClass('ant-dropdown-open')) {
           $(this).find('.b4gQjqmRH8tjkzGFg0E7').removeClass('ant-dropdown-open');
           $('#currency_window').find('.ant-dropdown').hide(100);
       } else {
           $(this).find('.b4gQjqmRH8tjkzGFg0E7').addClass('ant-dropdown-open');
           $('#currency_window').find('.ant-dropdown').css('left', $(this).offset().left).show(100);
       }
   });
   // 导航隐藏/显示
   $('.m7vhFTfzt4jM_ufvcChe').on('click', function(){
       if ($(this).hasClass('dYS8uSOMQHrio3m9xLYs')) {
           $(this).removeClass('dYS8uSOMQHrio3m9xLYs');
           $('.mgKfYplj9DFVFuDnQdmr').removeClass('PGqT5eNO1ftKSMJkwEQw');
           $('.qZX4PdIsh3gigKpYiGTc').removeClass('rr19G5MOkHl0_C_77mko');
       } else {
           $(this).addClass('dYS8uSOMQHrio3m9xLYs');
           $('.mgKfYplj9DFVFuDnQdmr').addClass('PGqT5eNO1ftKSMJkwEQw');
           $('.qZX4PdIsh3gigKpYiGTc').addClass('rr19G5MOkHl0_C_77mko');
       }
   });
   // 登出
   $('#logout').on('click', function(){
        $.post('/api/login/logout?lang='+$.cookie('language'),function(rs){
            location.reload();
        },'Json');
   });
   // 弹出窗口关闭
   $('.ant-modal-close').on('click',function(e){
       $(this).parent().parent().parent().parent().hide();
   });
   // fuck you pc 登录注册窗口打开
   $(document).on('click', '#open-register, #open-login', function(e){
       var id = e.target.id;
       if (id == 'open-login') {
           $('#login_window').show();
       }
       if (id == 'open-register') {
           $('#register_window').show();
       }
   });
   // 登录注册按钮切换
   $(document).on('click', '.register-open, .login-open', function(e){
       if ($(this).hasClass('login-open')) {
           $('#register_window').hide();
           $('#login_window').show();
       }
       if ($(this).hasClass('register-open')) {
           $('#login_window').hide();
           $('#register_window').show();
       }
   });
     // Login 登录验证
     $(document).on('blur', '#user_name,#password', function(e){
        var id = e.target.id;
        checkVerificationCall(id);
    });
    // Register 注册验证
    $(document).on('blur', '#register-user_name,#register-password,#register-password_re,#register-phone', function(e){
        var id = e.target.id;
        checkVerificationCall(id);
    });
    // 密码眼睛
    $('.ant-input-suffix').on('click', function(){
        var eye_status = $(this).prev()[0]['type'] == 'password' ? 'show' : 'hide';
        var eye_html = verification['password-eye-'+eye_status];
        if (eye_status == 'show') {
          $(this).prev().attr('type','text');
        } else {
          $(this).prev().attr('type','password');
        }
        $(this).html(eye_html);
     });
      // Login登录  fuck you pc 
    $('#submitLogin').on('click',function(){
        var user_name = checkVerificationCall('user_name');
        var password  = checkVerificationCall('password');
        if (!user_name || !password) {
            return false;
        }
        $(this).addClass('ant-btn-loading').prepend(verification['btnIcon']);
        var data = {};
			data['user_name'] = $('#user_name').val();
			data['password'] = md5($('#password').val());
		var _this = $(this);
		$.post('/api/login/login?lang='+$.cookie('language'),data,function(rs){
			if (rs.status > 0) {
                Qmsg.error(rs.message);
                _this.removeClass('ant-btn-loading').find('.anticon-loading').remove();
			} else {
				location.reload();
			}
		},'Json');
    });

    // Register注册
    $('#submitRegister').on('click',function(){
        var user_name = checkVerificationCall('register-user_name');
        var password  = checkVerificationCall('register-password');
        var password_re  = checkVerificationCall('register-password_re');
        var phone = checkVerificationCall('register-phone');

        // if (!wallet_name) {
        //     $('#open_wallet').parent().parent().parent().addClass('has-error').find('.ant-form-explain').text(verification['wallet']['empty']).show(100);
        // } else {
        //     $('#open_wallet').parent().parent().parent().removeClass('has-error').find('.ant-form-explain').text('').hide();
        // }

        if (!user_name || !password || !password_re || !phone) {
            return false;
        }

        var data = {
            user_name: $('#register-user_name').val(),
            password: md5($('#register-password').val()),
            confirm_password: md5($('#register-password_re').val()),
            real_name: $('#real_name').val(),
            phone: $('#register-phone').val(),
            coin_type: 'BRL'
        };

        $(this).addClass('ant-btn-loading').prepend(verification['btnIcon']);
        var _this = $(this);

        $.post('/api/register/register?lang='+$.cookie('language'),data,function(data){
            if (data.status == 0) {
                location.reload();
            } else {
                Qmsg.error(data.message);
                _this.removeClass('ant-btn-loading').find('.anticon-loading').remove();
            }
        },'json');
    });
    
    // 复制
    var clipboard = new ClipboardJS('.copy_value', {
        text: function(trigger) {
            return $(trigger).prev().text() || $(trigger).prev().val();
        }
    });
    clipboard.on('success', function(e){
        Qmsg.success(e.text);
    });
    clipboard.on('error', function(e){
        console.log(e);
    });
     // 验证共有方法
    function checkVerificationCall(id) {
        var value = $('#'+ id).val();
        // 登录
        if (id == 'user_name') {
            if (!value || value.length < 4 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'password') {
            if (!value || value.length < 6 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        // 注册
        if (id == 'register-user_name') {
            if (!value || value.length < 4 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'register-password') {
            if (!value || value.length < 6 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
			if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,16}$/.test(value)) {
                return checkVerification(id, 'strength', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'register-password_re') {
            if (!value || value.length < 6 || value.length > 16) {
                return checkVerification(id, 'empty', 'error');
            }
            if (value != $('#register-password').val()) {
                return checkVerification(id, 'confirm', 'error');
            }
            return checkVerification(id, '', 'success');
        }
        if (id == 'register-phone') {
            if (!value || value.length < 11 || isNaN(value*1)) {
                return checkVerification(id, 'empty', 'error');
            }
            return checkVerification(id, '', 'success');
        }
    }
    function checkVerification(id, error_type, type) {
        var el = $('#'+ id);
        if (type == 'error') {
            el.parents('.ant-form-item-control').addClass('has-error').find('.ant-form-explain').text(verification[id][error_type]).show(100);
            return false;
        }
        if (type == 'success') {
            el.parents('.ant-form-item-control').removeClass('has-error').find('.ant-form-explain').text('').hide();
        }
        return true;
    }
});
// })();
// (function(){
$(document).ready(function(){
   var bs = window.bs = BetterScroll.createBScroll('.scrollbar-wrapper', {
       probeType: 3,
       disableMouse: false,
       disableTouch: false,
       mouseWheel:true,
       scrollbar: {
           fade: false,
           scrollbarTrackClickable: true,
           interactive: true,
           customElements: [document.getElementById('vertical')]
       },
   });
   var leftNavIcon = {
       'menu1': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_0.4018a1d48e82cc57d425.png" alt="." data-status="loaded" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 19.2 20.38" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_0--sprite"></use></svg></i>',
       },
       'menu2': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_3.42ee634107f13c757715.png" alt="." data-status="loaded" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 32.4 19.581" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_3--sprite"></use></svg></i>',
       },
       'menu3': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_2.54fe03ef5cbd0b54e1ad.png" alt="." data-status="loaded" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 22.4 24.003" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_2--sprite"></use></svg></i>',
       },
       'menu4': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_5.749b51ffa1d6658f6dda.png" alt="." data-status="loaded" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 24.4 24.676" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_5--sprite"></use></svg></i>',
       },
       'menu5': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_4.baac3e3365a9a9f81f2e.png" alt="." data-status="loaded" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26 26.497" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_4--sprite"></use></svg></i>',
       },
       'menu6': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_1.b323ae91b000369a078d.png" alt="." data-status="loaded" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 32 20.882" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_1--sprite"></use></svg></i>',
       },
       'menu9': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_100.142dc1089c51a050e845.png" alt="." data-status="success" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 22.001 22.001" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_100--sprite"></use></svg></i>',
       },
       'menu10': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_101.5f31288421d08822a9c2.png" alt="." data-status="success" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 26.844 25.054" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_101--sprite"></use></svg></i>',
       },
       'menu11': {
           'selected' : '<img src="/static/image_v2/icon_game_menu_active_113.3e69c12da4907c6e4f33.png" alt="." data-status="success" class="goDRiiBsuEuXD3W1NphN">',
           'default': '<i style="display: inline-flex; justify-content: center; align-items: center;"><svg viewBox="0 0 25.599 20.494" width="1em" height="1em" fill="currentColor" aria-hidden="true" focusable="false"><use xlink:href="/static/image_v2/sprite.010f33e9e238aee0f859.svg#icon_game_menu_active_113--sprite"></use></svg></i>',
       },
   };
   var prevClickEl = 'menu1';
   bs.on('scrollEnd', function(pos){
       var top, id;
       $('#anchor-wrapper').find('.PHA2wR0MEPHBvH62Pxgy').each(function(){
           top = $(this).offset().top;
           if ((top < 60 && top > 0) || (top < 0 && top > -250)) {
               id = $(this)[0].id;
               return false;
           }
       });
       if (pos.y > -400) {
           id = 'menu1';
       }
       if (id) {
           navBarLinkage($('#leftnavbar').find('div[data-key=\''+id+'\']'), 'leftnavbar', 'rTlEIxYgbDf9QFPq5wNJ', 'wFkrzkt80ExmvJDvJETQ', 'dJm2vYeX32a1uQj2A68G', 'scroll');
           navBarLinkage($('#right-nav-bar').find('div[data-key=\''+id+'\']'), 'right-nav-bar', 'c37jM5XQ9O8_QQS38kzg', 'dO86rxT8syHm361TBCRD', 'spriteImg', 'scroll');
           prevClickEl = id;
       }
       if (pos.y < -200) {
           $('.GNQcsQFKCZ6OZnz0koI7').css('opacity',1);
       } else {
           $('.GNQcsQFKCZ6OZnz0koI7').css('opacity',0);
       }
   });
   $('.GNQcsQFKCZ6OZnz0koI7').on('click', function(){
            bs.scrollToElement($('#home-scroll-box')[0]);
   });
   $('#leftnavbar').find('.rTlEIxYgbDf9QFPq5wNJ').on('click',function(e){
       try {
            var key = navBarLinkage(this, 'leftnavbar', 'rTlEIxYgbDf9QFPq5wNJ', 'wFkrzkt80ExmvJDvJETQ', 'dJm2vYeX32a1uQj2A68G');
            $('#right-nav-bar').find('div[data-key=\''+key+'\']').click();
            prevClickEl = key;
       } catch(e) {
            location.href = '/index';
       }
   });
   var bs2 = BetterScroll.createBScroll('#scrollbar-warpper', {
       probeType: 3,
       scrollX:true,
   });
   // bs2.scrollTo(-200,0,100);
   $('#right-nav-bar').on('click','.c37jM5XQ9O8_QQS38kzg',function(){
        var key = navBarLinkage(this, 'right-nav-bar', 'c37jM5XQ9O8_QQS38kzg', 'dO86rxT8syHm361TBCRD', 'spriteImg');
        $('#leftnavbar').find('div[data-key=\''+key+'\']').click();
        prevClickEl = key;
   });
   $('#close_menu7').on('click', function(){
       $('#menu7').hide();
   });
   $('.jZMuRUTa2bTzdS2dyagQ').on('click',function(){
       // if (!$(this).hasClass('dbnone')) {
           var id = $(this)[0].id;
           // $(this).addClass('dbnone');
           if (id == 'leftBtnNavBar') {
               bs2.scrollTo(0,0,100);
               // $('#rightBtnNavBar').removeClass('dbnone');
           }
           if (id == 'rightBtnNavBar') {
               bs2.scrollTo(-150,0,100);
               // $('#leftBtnNavBar').removeClass('dbnone');
           }
       // }
   });
   function navBarLinkage(_this, navId, thisClick, thiSelected, findEl, scrollVal) {

       var key = $(_this).attr('data-key');
       var location = $(_this).attr('data-location');
       var page = $(_this).attr('data-page');
       var scroll = scrollVal || '';

       if ($(_this).hasClass(thiSelected)) {
           return;
       }

       // 浏览器指定位置
       if ((location == 'false' || !location) && !page) {
           $(_this).parent().find('div[data-key=\''+prevClickEl+'\']').find('.'+ findEl).html(leftNavIcon[prevClickEl]['default']);
           $(_this).parent().find('.'+ thisClick).removeClass(thiSelected);
           $(_this).addClass(thiSelected).find('.'+ findEl).html(leftNavIcon[key]['selected']);
           if (!scroll) {
               bs.scrollToElement($('#'+ key)[0]);
           }
       } else if(location == 'true') { // 弹窗跳转
           $('#menu7').show();
       }

       return key;
   }
// })();
});
