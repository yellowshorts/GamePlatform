<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\index\controller\Admin;

class Withdraw extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        $user_info = parent::getUserInfo();
        if (empty($user_info['withdrawal_password'])) {
            $this->redirect('/index/WithdrawPIN');
        }
        $userAccount = Db::table('users_account')->where('user_id', Session::get('user_id'))->field('id,account_type,account_number,default')->select();
        $userAccountTotal = count($userAccount);
        $this->assign('userAccount', $userAccount);
        $this->assign('userAccountTotal', $userAccountTotal);
        return $this->fetch();
    }
}
