<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Session;
use app\index\controller\Admin;
use app\api\model\VipModel;
use app\api\controller\ShareStatistics;

class Promotions extends Admin
{
    public function __construct() {
		parent::__construct();
	}
    
    public function index()
    {
        // 宝箱数据
        $vipModel = new VipModel;
        $inviteBoxList = $vipModel->getBoxList(0,1);
        $data = [];
        $row = 0;
        $rowSon = 5;
        foreach ($inviteBoxList as $k => $v) {
            $num = $k + 1;
            if ($num % $rowSon == 0) {
                $row += 1;
            }
            if (empty($data[$row])) {
                $data[$row] = [];
            }
            $data[$row][] = $v;

        }
        $this->assign('inviteBoxList', $data);

        // 分享佣金数据
        $shareStatisticsCtrl = new ShareStatistics;
        // 当天日期
        $beginTime = date('Y-m-d',time())." 00:00:00";
        $endTime = date('Y-m-d',time())." 23:59:59";
        // 组装数据
        $shareData = [];
        // 邀请总人数
        $shareData['SubNumberTotal'] = $shareStatisticsCtrl->getSubNumberTotal(Session::get('user_id'));
        // 邀请佣金
        $shareData['SubRegisterCommission'] = $shareStatisticsCtrl->getSubRegisterCommission(Session::get('user_id'));
        // 今日邀请人数
        $shareData['todaySubNumberTotal'] = $shareStatisticsCtrl->getSubNumberTotal(Session::get('user_id'), $beginTime, $endTime);
        // 今日邀请佣金
        $shareData['todaySubRegisterCommission'] = $shareStatisticsCtrl->getSubRegisterCommission(Session::get('user_id'), strtotime($beginTime), strtotime($endTime));
        // 充值人数
        $shareData['SubPaymentNumberTotal'] = $shareStatisticsCtrl->getSubPaymentNumberTotal(Session::get('user_id'));
        // 充值佣金
        $shareData['SubPaymentCommission'] = $shareStatisticsCtrl->getSubPaymentCommission(Session::get('user_id'));
        // 今日充值人数
        $shareData['todaySubPaymentNumberTotal'] = $shareStatisticsCtrl->getSubPaymentNumberTotal(Session::get('user_id'), strtotime($beginTime), strtotime($endTime));
        // 今日充值佣金
        $shareData['todaySubPaymentCommission'] = $shareStatisticsCtrl->getSubPaymentCommission(Session::get('user_id'), strtotime($beginTime), strtotime($endTime));
        // 全部佣金（注册佣金+充值佣金）
        $shareData['allCommission'] = $shareData['SubRegisterCommission'] + $shareData['SubPaymentCommission'];
        // 今日佣金（注册佣金+充值佣金）
        $shareData['todayCommission'] = $shareData['todaySubRegisterCommission'] + $shareData['todaySubPaymentCommission'];
        // 下级投注信息
        $shareData['SubBetMoenyNumberTotal'] = $shareStatisticsCtrl->getSubBetMoenyNumberTotal(Session::get('user_id'));

        $this->assign('shareData', $shareData);

        $this->assign('controller', request()->controller());
        return $this->fetch();
    }
}
