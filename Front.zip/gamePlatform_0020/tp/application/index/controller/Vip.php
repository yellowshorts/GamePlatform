<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Session;
use app\index\controller\Admin;
use app\api\model\VipModel;

class Vip extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        $vipModel = new VipModel;
        $vipBoxList = $vipModel->getVipBoxList(0,1);
        $vipConfigList = $vipModel->viewVipPage(Session::get('user_id'));
        $this->assign('vipConfigList', $vipConfigList['result']);
        $this->assign('vipBoxList', $vipBoxList);
        $this->assign('controller', request()->controller());
        return $this->fetch();
    }
}
