<?php
namespace app\index\controller;
use think\Controller;
use app\index\controller\Admin;

class Rewards extends Admin
{
    public function __construct() {
		parent::__construct();
	}
    
    public function index()
    {
        $this->assign('controller', request()->controller());
        return $this->fetch();
    }
}
