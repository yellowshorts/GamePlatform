<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\index\controller\Parents;

class Home extends Parents
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        if (empty(cookie('language'))) {
            Cookie::forever('language','en-us');
        }
        return $this->fetch();
    }
    
    public function Changelanguage() {
        $id = input('param.id');
        if ($id == '1') {
            Cookie::forever('language','en-us');
        }
        if ($id == '2') {
            Cookie::forever('language','zh-cn');
        }
        return redirect('/index');
    }
}
