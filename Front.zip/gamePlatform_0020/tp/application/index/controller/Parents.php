<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\api\model\LoginModel;
use app\api\model\AupayModel;
use app\api\model\CustomerSeviceModel;

class Parents extends Controller
{
    public function __construct()
    {
		parent::__construct();
		if (Session::get('user_id') > 0) {
            $loginModel = new LoginModel;
            $user_info = $loginModel->get_column(['user_id','user_name','real_name','email','area_code','phone','parent_id','coin_type','birthdate','brl_wallet','vnd_wallet'],['user_id' => Session::get('user_id')]);
            $this->assign('user_info', $user_info);
        }
        $aupayModel = new AupayModel();
        $this->assign('paymentList', $aupayModel->getPaymentList());
        if (empty(Session::get('pid'))) {
            Session::set('pid', intval(input('get.pid')));
        }
        $customerModel = new CustomerSeviceModel;
        $this->assign('customerList', $customerModel->getCustomerSeviceList());
        $this->assign('controllerName', request()->controller());
    }
}
