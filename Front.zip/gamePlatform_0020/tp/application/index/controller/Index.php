<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\index\controller\Parents;
use app\api\model\GameModel;
use app\api\model\ActivityModel;

class Index extends Parents
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        if (empty(cookie('language'))) {
            Cookie::forever('language','en-us');
            Cookie::forever('think_var','en-us');
        }
        $gameModel = new GameModel;
        $this->assign('gameList', $gameModel->getGameList('','',20));
        $this->assign('hotGameList', $gameModel->getGameList('','',20,'',1,'hot'));

        $activityModel = new ActivityModel;
        $this->assign('bannerList', $activityModel->getBanner());
        $this->assign('marqueeList', $activityModel->getMarquee());
        return $this->fetch();
    }
    
    public function Changelanguage() {
        $id = input('param.id');
        if ($id == '1') {
            Cookie::forever('language','en-us');
            Cookie::forever('think_var','en-us');
        }
        if ($id == '2') {
            Cookie::forever('language','pt-pt');
            Cookie::forever('think_var','pt-pt');
        }
        return redirect('/index');
    }
}
