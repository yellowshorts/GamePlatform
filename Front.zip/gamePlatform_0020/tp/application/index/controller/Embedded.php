<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\index\controller\Admin;
use app\api\model\GameModel;
use app\api\controller\Game;
use think\facade\Log;

class Embedded extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
       $gameid = input('id');
       $gameCtrl = new Game;
       Log::write("1.0.0.1",'Embedded ');
       $playerAccount = $gameCtrl->creatPlayer($gameid);
       if ($playerAccount['status'] == 1) {
            echo '<script>alert("'.$playerAccount['message'].'"); location.href = "/index";</script>';
            die;
       }
       Log::write("1.0.0.2",'Embedded ');
       $createGame = $gameCtrl->createGame($gameid, $playerAccount['result']['playerAccount']);
       Log::write("1.0.0.3",'Embedded ');

       if ($createGame['code'] != 10000) {
            echo '<script>alert("'.$createGame['msg'].'"); location.href = "/index";</script>';
            die;
       }
       
       $this->assign('playerAccount', $playerAccount);
       $this->assign('createGame', $createGame);
       return $this->fetch();
    }
}
