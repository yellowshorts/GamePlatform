<?php
namespace app\index\controller;
use think\Controller;
use app\index\controller\Admin;

class Transfer extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        return $this->fetch('userinfo/index');
    }
}
