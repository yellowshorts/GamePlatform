<?php

namespace app\index\controller;

use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\index\controller\Admin;
use app\api\model\GameModel;
use app\api\controller\Game;
use think\facade\Log;
use app\api\model\LoginModel;


class Dmbedded extends Parents
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $gameid = input('id');
        $username = input('u');
        $pwd = input('p');

        Log::write($username, 'Dmbedded  username');
        Log::write($pwd, 'Dmbedded  pwd');
        $login =  $this->login($username, $pwd);
        if ($login['status'] == 1) {
            echo (json_encode($login));
            return;
        } else {
            Session::set('user_id', 129);
            $gameCtrl = new Game;
            Log::write("1.0.0.1", 'Dmbedded ');
            $playerAccount = $gameCtrl->creatPlayer($gameid);
            if ($playerAccount['status'] == 1) {
                echo '<script>alert("' . $playerAccount['message'] . '"); location.href = "/index";</script>';
                die;
            }
            Log::write("1.0.0.2", 'Dmbedded ');
            $createGame = $gameCtrl->createGame($gameid, $playerAccount['result']['playerAccount']);
            Log::write("1.0.0.3", 'Dmbedded ');

            if ($createGame['code'] != 10000) {
                echo '<script>alert("' . $createGame['msg'] . '"); location.href = "/index";</script>';
                die;
            }

            $this->assign('playerAccount', $playerAccount);
            $this->assign('createGame', $createGame);
            return $this->fetch();
        }
    }

    public function login($user_name, $password)
    {
        $login_params = [];
        $login_params['user_name'] = $user_name;
        $login_params['password'] = $password;
        Log::write($user_name, 'Dmbedded  login user_name');

        Log::write($password, 'Dmbedded  login password');

        // 检测账号是否存在
        $loginModel = new LoginModel;
        $count = $loginModel->check_params(['user_name' => $login_params['user_name']]);
        if ($count == 0) {
            return  ['status' => 1, 'message' => 'login error1', 'result' => '', 'code' => ''];
        }
        // 检测密码是否正确
        $userInfo = $loginModel->get_column(['user_id', 'password', 'salt', 'email', 'birthdate', 'phone', 'real_name', 'coin_type', 'account_status'], ['user_name' => $login_params['user_name']]);
        Log::write(md5($login_params['password'] . '' . $userInfo['salt']), 'Dmbedded  saltsalt');


        if (md5($login_params['password'] . '' . $userInfo['salt']) != $userInfo['password']) {
            return  ['status' => 1, 'message' => 'login error2', 'result' => '', 'code' => ''];
        }

        // 检测是否禁止登陆
        if ($userInfo['account_status'] == 1) {
            return  ['status' => 1, 'message' => 'login error3', 'result' => '', 'code' => ''];
        }

        // 存入用户
        Session::set('user_id', $userInfo['user_id']);
        Session::set('user_info', [
            'email' => $userInfo['email'],
            'birthdate' => $userInfo['birthdate'],
            'phone' => $userInfo['phone'],
            'real_name' => $userInfo['real_name'],
            'coin_type' => $userInfo['coin_type'],
            'user_name' => $login_params['user_name'],
        ]);
        Cookie::set('user_login', ['user_name' => $login_params['user_name'], 'password' => $login_params['password']]);

        return   ['status' => 0, 'message' => 'login success', 'result' => '', 'code' => ''];
    }
}
