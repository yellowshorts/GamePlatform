<?php
namespace app\index\controller;
use think\Controller;
use app\index\controller\Parents;

class Support extends Parents
{
    public function __construct() {
		parent::__construct();
	}
    
    public function index()
    {
        $this->assign('controller', request()->controller());
        return $this->fetch();
    }
}
