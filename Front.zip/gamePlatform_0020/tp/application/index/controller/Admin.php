<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\api\model\LoginModel;
use app\api\model\AupayModel;
use app\api\model\CustomerSeviceModel;

class Admin extends Controller
{
    public function __construct()
    {
		parent::__construct();
		$res = $this->checkLogin();
		if(!$res){
			$this->redirect('/');
		}
        $user_info = $this->getUserInfo();
        $this->assign('user_info', $user_info);
        $aupayModel = new AupayModel();
        $this->assign('paymentList', $aupayModel->getPaymentList());
        $customerModel = new CustomerSeviceModel;
        $this->assign('customerList', $customerModel->getCustomerSeviceList());
        $this->assign('controllerName', request()->controller());
    }

    public function checkLogin() {
        if (empty(Session::get('user_id'))) {
            return false;
        }
        return true;
    }

    public function getUserInfo() {
        $loginModel = new LoginModel;
        return $loginModel->get_column(['user_name','real_name','card_number','email','area_code','phone','parent_id','coin_type','birthdate','brl_wallet','vnd_wallet','withdrawal_password'],['user_id' => Session::get('user_id')]);
    }
}
