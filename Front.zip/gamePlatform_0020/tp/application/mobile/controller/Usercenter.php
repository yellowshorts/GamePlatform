<?php
namespace app\mobile\controller;
use think\Controller;
use app\mobile\controller\Admin;

class Usercenter extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        return $this->fetch();
    }
}
