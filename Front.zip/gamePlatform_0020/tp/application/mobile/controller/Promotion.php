<?php
namespace app\mobile\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\mobile\controller\Admin;

class Promotion extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        return $this->fetch();
    }
}
