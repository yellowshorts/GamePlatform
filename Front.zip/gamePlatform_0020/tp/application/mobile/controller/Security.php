<?php
namespace app\mobile\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\mobile\controller\Admin;

class Security extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        $user_info = parent::getUserInfo();
        $this->assign('user_info', $user_info);
        return $this->fetch();
    }
}
