<?php
namespace app\mobile\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\index\controller\Admin;
use app\api\model\GameModel;
use app\api\controller\Game;

class Embedded extends Admin
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
       $gameid = input('id');
       $gameCtrl = new Game;
       $playerAccount = $gameCtrl->creatPlayer($gameid);
       if ($playerAccount['status'] == 1) {
            echo '<script>alert("'.$playerAccount['message'].'"); location.href = "/mobile";</script>';
            die;
       }
       $createGame = $gameCtrl->createGame($gameid, $playerAccount['result']['playerAccount']);
       if ($createGame['code'] != 10000) {
            echo '<script>alert("'.$createGame['msg'].'"); location.href = "/mobile";</script>';
            die;
       }
       $this->assign('playerAccount', $playerAccount);
       $this->assign('createGame', $createGame);
       return $this->fetch();
    }
}
