<?php
namespace app\mobile\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\api\model\LoginModel;
use app\api\model\AupayModel;

class Admin extends Controller
{
    public function __construct()
    {
		parent::__construct();
		$res = $this->checkLogin();
		if(!$res){
			$this->redirect('/');
		}
        $user_info = $this->getUserInfo();
        $this->assign('user_info', $user_info);
        $this->assign('controller_name', request()->controller());
        $aupayModel = new AupayModel();
        $this->assign('paymentList', $aupayModel->getPaymentList());
    }

    public function checkLogin() {
        if (empty(Session::get('user_id'))) {
            return false;
        }
        return true;
    }

    public function getUserInfo() {
        $loginModel = new LoginModel;
        return $loginModel->get_column(['user_name','real_name','card_number','email','area_code','phone','parent_id','coin_type','birthdate','brl_wallet','vnd_wallet','withdrawal_password'],['user_id' => Session::get('user_id')]);
    }
}
