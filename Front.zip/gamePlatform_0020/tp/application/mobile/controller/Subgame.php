<?php
namespace app\mobile\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\mobile\controller\Parents;
use app\api\model\GameModel;

class Subgame extends Parents
{
    public function __construct() {
		parent::__construct();
	}

    public function index()
    {
        $platform = !empty(input('platform')) ? explode(',',input('platform')) : ['pg','other'];
        if (count($platform) == 1) {
            $platform = $platform[0];
        }
        $gametype = input('gametype');
        $page = intval(input('page')) == 0 ? 1 : intval(input('page'));
        $limit = 50;
        $searchtype = !empty(input('searchtype')) ? input('searchtype') : 'all';
        $gameModel = new GameModel;
        $this->assign('gameList', $gameModel->getGameList($platform,$gametype,$limit,0,$page,$searchtype));
        $this->assign('gamePage', $gameModel->getGameCount($platform,$gametype,$limit,$searchtype));
        $this->assign('platform', !empty(input('platform')) ? input('platform') : 'pg,other');
        $this->assign('gametype', input('gametype'));
        $this->assign('limit', input('limit'));
        $this->assign('page', $page);
        $this->assign('searchtype', $searchtype);
        return $this->fetch();
    }
}
