<?php

namespace app\channel\controller;

use think\App;
use think\Db;
use think\Exception;
use think\Request;
use app\channel\controller\Base;

class Api extends Base
{
	
	public function index()
	{
		echo 'index api';
		exit;
	}
    //登录
    public function Login()
	{
		echo 'index Login';
		exit;
	}
    //建立账号
	public function createMember()
	{
		echo 'index createMember';
		exit;
	}

    //注销游戏
    public function KickMember()
	{
		echo 'index KickMember';
		exit;
	}
    //查询会员状态
    public function GetMemberInfo()
	{
		echo 'index GetMemberInfo';
		exit;
	}

    //查询所有在线玩家账号
    public function GetOnlineMember()
	{
		echo 'index GetOnlineMember';
		exit;
	}
    //查询一笔额度转移纪录
    public function CheckTransferByTransactionId()
	{
		echo 'index CheckTransferByTransactionId';
		exit;
	}

     //查询额度转移纪录 (依时间范围)
     public function GetTransferRecordByTime()
     {
         echo 'index GetTransferRecordByTime';
         exit;
     }

     //3.1.8 查询游戏纪录 (依时间范围)
     public function GetBetRecordByTime()
     {
         echo 'index GetTransferRecordByTime';
         exit;
     }
     //3.1.10 查询游戏清单
     public function GetGameList()
     {
         echo 'index GetGameList';
         exit;
     }
     //3.1.11 取得注单详细结果连结
     public function GetGameDetailUrl()
     {
         echo 'index GetGameDetailUrl';
         exit;
     }
}