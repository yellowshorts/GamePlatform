<?php


namespace app\channel\controller;

    
use Cassandra\Varint;
use think\Db;
use think\Request;
use think\Response;
   
class Base
{

    public $uid;

    public function __construct()
    {

        //每个接口的header头部传token信息过来
        $token = request()->header("TOKEN");
        $token = 1231312;

        if (empty($token)) {
            json(array('code'=>'2','data'=>'登录状态失效,请重新登录！'))->send();exit();
        }


        //根据token查询用户信息
        //$data = Db::name('member')->where(['token' => $token])->find();
        $data  = array(
            "id" =>  2222,
        );
        

        if (empty($data)) {   
            json(array('code'=>'2','data'=>'登录状态失效,请重新登录！'))->send();exit();
        } else {
            $this->uid = $data['id'];
        }


    }
}