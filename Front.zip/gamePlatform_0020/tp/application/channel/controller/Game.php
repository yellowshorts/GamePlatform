<?php
namespace app\channel\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\channel\model\GameModel;
use app\channel\model\PlayerModel;
use app\channel\model\UserModel;
use think\facade\Log;

class Game extends Base
{
    static $sn = 'r67';

    static $secret = 'L2Mj10G2C14y4qD4m43088OM9v5970uB';

    static $url = 'https://ap.api-bet.net';

    // 创建平台用户账号
    static $createPlayerAccountUrl = '/api/server/create';

    // 试玩游戏链接
    static $createDemoGameUrl = '/api/server/demoUrl';
    
    // 正式游戏链接
    static $createFormalGameUrl = '/api/server/gameUrl';

    // 判断是否登录
    // public function __construct() {
    //     parent::__construct();
    //     if (!$this->check_login()) {
    //         return $this->_error('check','login',10001);
    //     }
    // }


    public function createGame($gameid, $playerAccount) {
        $gameModel = new GameModel;
        Log::write("2.0.0",'createGame ');
        $gameRes = $gameModel->getGameList('','','',$gameid);
        if (count($gameRes) == 0) {
            return ['status' => 1, 'message' => 'This game was not found', 'result' => ''];
        }
        // 自营平台
        if ($gameRes['platType'] == 'pg' || $gameRes['platType'] == 'other') {
            Log::write("2.0.1: ".config('app_host').":13001/getApiGameUrl/?gameId={$gameRes['gameCode']}&uid={$playerAccount}",'createGame ');
            $res = json_decode(file_get_contents(config('app_host').":13001/getApiGameUrl/?gameId={$gameRes['gameCode']}&uid={$playerAccount}"),true);
            Log::write($res,'createGame res');
            return ['code' => 10000, 'data' => ['url' => $res['url']]];
        } else { // 其他平台
            $sign = $this->sign();
            $header = [
                'Content-Type: application/json',
                'sign: '. $sign['sign'],
                'random: '. $sign['randomCode'],
                'sn: '. self::$sn,
            ];
            $data = [
                'playerId' => $playerAccount,
                'gameType' => $gameRes['gameType'],
                'platType' => $gameRes['platType'],
                'currency' => 'CNY',
                'lang' => 'en',
                'ingress' => 1,
                'gameCode' => $gameRes['gameCode']
            ];
            
            $res = __postJson(self::$url.self::$createFormalGameUrl, json_encode($data), $header);
            return json_decode($res,true);
        }
    }
    
    public function creatPlayer($gameid) {
        $gameModel = new GameModel;
        Log::write("1.0.0",'creatPlayer');
        $gameRes = $gameModel->getGameList('','','',$gameid);
        if (count($gameRes) == 0) {
            return ['status' => 1, 'message' => 'This game was not found', 'result' => ''];
        }
        $playerModel = new PlayerModel;
        $playerCount = $playerModel->searchPlayer(Session::get('user_id'), $gameRes['platType']);
        $flag = false;
        Log::write("1.0.1",'creatPlayer');
        if (empty($playerCount)) {
            Log::write("1.0.1.0",'creatPlayer');
            $playerAccount = $this->createPlayerAccount();
            $flag = true;
        } else {
            Log::write("1.0.1.1",'creatPlayer');
            $playerAccount = $playerCount['playerId'];
        }
        if ($gameRes['platType'] == 'pg' || $gameRes['platType'] == 'other') {
            Log::write("1.0.2.1",'creatPlayer');
            $flag && $playerModel->savePlayer([
                'user_id' => session::get('user_id'),
                'platType' => $gameRes['platType'],
                'playerId' => $playerAccount,
                'currency' => 'CNY',
                'create_at' => time(),
            ]);
        } else {
            Log::write("1.0.2.2",'creatPlayer');
            $sign = $this->sign();
            $header = [
                'Content-Type: application/json',
                'sign: '. $sign['sign'],
                'random: '. $sign['randomCode'],
                'sn: '. self::$sn,
            ];
            $data = [
                'playerId' => $playerAccount,
                'platType' => $gameRes['platType'],
                'currency' => 'CNY'
            ];
            Log::write(self::$url,'creatPlayer $url');
            Log::write(self::$createPlayerAccountUrl,'creatPlayer $createPlayerAccountUrl');
            $res = __postJson(self::$url.self::$createPlayerAccountUrl, json_encode($data), $header);
            $res = json_decode($res,true);
            Log::write($res,'creatPlayer $res');
            if ($res['code'] == 10000) {
                $playerModel->savePlayer([
                    'user_id' => session::get('user_id'),
                    'platType' => $gameRes['platType'],
                    'playerId' => $playerAccount,
                    'currency' => 'CNY',
                    'create_at' => time(),
                ]);
            } else {
                return ['status' => 1, 'message' => $res['msg'], 'result' => ''];
            }
        }
        
        return ['status' => 0, 'message' => 'ok', 'result' => ['playerAccount' => $playerAccount, 'game_info' => $gameRes]];
        
    }

    public function createPlayerAccount() {
        return GetRandStr(4,'str').'0'.session::get('user_id');
    }

    public function sign() {
        $randomCode = GetRandStr(16);
        return ['randomCode' => $randomCode, 'sign' => md5($randomCode.self::$sn.self::$secret)];
    }

    public function getWalletBalance() {
        $uid = input('post.uid');
        $playerModel = new PlayerModel;
        $user_id = $playerModel->searchPlayer(0, '', $uid)['user_id'];
        $userModel = new UserModel;
        $userBalance = $userModel->getUser($user_id)['brl_wallet'];
        return ['code' => 1, 'msg' => 'success', 'balance' => intval($userBalance * 100)];
    }

    public function changeWalletBalance() {
        $uid = input('post.uid');
        $changemoney = input('post.changemoney');
        $bet = input('post.bet');
        $win = input('post.win');
        $playerModel = new PlayerModel;
        $user_id = $playerModel->searchPlayer(0, '', $uid)['user_id'];
        $userModel = new UserModel;
        $userBalance = $userModel->getUser($user_id)['brl_wallet'];
        if ($userBalance + ($changemoney/100) < 0) {
            return ['code' => 0, 'msg' => 'error'];
        }
        Db::table('users')->where('user_id', $user_id)->inc('brl_wallet', ($changemoney/100))->update();
        return ['code' => 1, 'msg' => 'success'];
    }

    public function getSelfGameList() {
        $gameList = json_decode(file_get_contents('http://106.15.89.255:13001/getApiGameList'),true);
        // 整理数组
        $data = [];
        foreach ($gameList['data'] as $k => $v) {
            $data[] = [
                'platType' => 'pg',
                'gameType' => $v['GameType'],
                'gameCode' => $v['GameId'],
                'gameBgUrl' => $v['serverInfo']['normal'][0]['GameBg'],
                'GameDirection' => $v['GameDirection'],
                'ingress' => 3,
                'gameName' => json_encode(['zh_hans' => $v['GameName_zh'], 'en' => $v['GameName']]),
                'imageUrl' => json_encode(['en' => ['square' => $v['serverInfo']['normal'][0]['GameImage']]]),
            ];
        }
        Db::table('game_list')->strict(false)->insertAll($data);
    }
}