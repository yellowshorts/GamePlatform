<?php
namespace app\channel\model;
use think\Model;
use think\Db;

class UserModel extends Model {

    public function getUserAccount($account_id, $user_id) {
        return Db::table('users_account')->where('id', $account_id)->where('user_id', $user_id)->find();
    }

    public function getUser($user_id) {
        return Db::table('users')->where('user_id', $user_id)->find();
    }
}