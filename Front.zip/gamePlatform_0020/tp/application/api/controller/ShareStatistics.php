<?php
namespace app\api\controller;
use think\Controller;
use think\Db;

class ShareStatistics extends Parents
{
    // 获取下级总注册人数
    public function getSubNumberTotal($user_id, $beginTime = '', $endTime = '') {
        $sql = Db::table('users')->where('pid', $user_id);
        if (!empty($beginTime) && !empty($endTime)) {
            $sql->whereTime('reg_time',[$beginTime, $endTime]);
        }
        return $sql->count();
    }

    // 获取下级注册佣金
    public function getSubRegisterCommission($user_id, $beginTime = '', $endTime = '') {
        $sql = Db::table('system_activity_bonus_log sabl')->field('SUM(sabl.give_fee) give_fee')->where('sabl.user_id', $user_id)->where('sabl.activity_type', 4);
        if (!empty($beginTime) && !empty($endTime)) {
            $sql->where('sabl.creatime_at', 'between', [$beginTime, $endTime]);
        }
        return $sql->find()['give_fee'];
    }

    // 获取下级充值人数
    public function getSubPaymentNumberTotal($user_id, $beginTime = '', $endTime = '') {
        $sql = Db::table('admin_gameplatform_0020.users u')->join('ym_manage.paylog p','u.user_id=p.uid')->where('u.pid', $user_id)->where('p.type', 3)->where('p.status', 1);
        if (!empty($beginTime) && !empty($endTime)) {
            $sql->where('p.paytime', 'between', [$beginTime, $endTime]);
        }
        return $sql->count();
    }

    // 获取下级充值佣金
    public function getSubPaymentCommission($user_id, $beginTime = '', $endTime = '') {
        $sql = Db::table('system_activity_bonus_log sabl')->field('SUM(sabl.give_fee) give_fee')->where('sabl.user_id', $user_id)->where('sabl.activity_type', 5);
        if (!empty($beginTime) && !empty($endTime)) {
            $sql->where('sabl.creatime_at', 'between', [$beginTime, $endTime]);
        }
        return $sql->find()['give_fee'];
    }

    // 获取下级下注总额，下注次数
    public function getSubBetMoenyNumberTotal($user_id) {
        $sql = "SELECT T1.*, gu.Id gameUserId, SUM(mk.useCoin) useCoin, COUNT(1) betNumber FROM (
                SELECT u.user_id, CONCAT('user',p.playerId) playerId FROM admin_gameplatform_0020.users u 
                INNER JOIN admin_gameplatform_0020.players p ON u.user_id = p.user_id
                WHERE u.pid = '{$user_id}' ) T1
                INNER JOIN gameaccount.newuseraccounts gu ON T1.playerId = gu.Account
                INNER JOIN gameaccount.mark mk ON gu.Id = mk.userId";
        $result = Db::query($sql)[0];
        return ['betMoney' => $result['useCoin'], 'betNumber' => $result['betNumber']];
    }

    // 获取用户下注总额，下注次数
    public function getUserBetMoenyNumberTotal($user_id, $time = []) {
        $where = ' WHERE 1 ';
        if (!empty($time)) {
            $where .= " AND mk.balanceTime >= '".date('Y-m-d H:i:s', $time[0])."' AND mk.balanceTime <= '".date('Y-m-d H:i:s', $time[1])."'";
        }
        $sql = "SELECT T1.*, gu.Id gameUserId, SUM(mk.useCoin) useCoin, SUM(mk.winCoin) winCoin, COUNT(1) betNumber FROM (
                SELECT u.user_id, CONCAT('user',p.playerId) playerId FROM admin_gameplatform_0020.users u 
                INNER JOIN admin_gameplatform_0020.players p ON u.user_id = p.user_id
                WHERE u.user_id = '{$user_id}' ) T1
                INNER JOIN gameaccount.newuseraccounts gu ON T1.playerId = gu.Account
                INNER JOIN gameaccount.mark mk ON gu.Id = mk.userId
                {$where} ";
        $result = Db::query($sql)[0];
        return ['betMoney' => $result['useCoin'], 'betNumber' => $result['betNumber'], 'wl' => $result['winCoin']];
    }

    // 获取用户下注列表
    public function getUserBetMoenyList($user_id, $time) {
        $sql = "SELECT T1.*, gu.Id gameUserId, mk.id, mk.useCoin, mk.balanceTime, mk.winCoin, g.name gameName FROM (
                SELECT u.user_id, CONCAT('user',p.playerId) playerId FROM admin_gameplatform_0020.users u 
                INNER JOIN admin_gameplatform_0020.players p ON u.user_id = p.user_id
                WHERE u.user_id = '{$user_id}' ) T1
                INNER JOIN gameaccount.newuseraccounts gu ON T1.playerId = gu.Account
                INNER JOIN gameaccount.mark mk ON gu.Id = mk.userId
                INNER JOIN ym_manage.game g ON mk.gameId = g.gameid
                WHERE mk.balanceTime >= '".date('Y-m-d H:i:s', $time[0])."' AND mk.balanceTime <= '".date('Y-m-d H:i:s', $time[1])."'
                ORDER BY mk.balanceTime DESC";
        return Db::query($sql);
    }

    // 获取用户下所有赠送彩金
    public function getUserAllGiveWinnings($user_id) {
        return Db::table('system_activity_bonus_log')->where('user_id', $user_id)->field('SUM(give_fee) give_fee')->find()['give_fee'];
    }

    // 获取用户下所有赠送彩金（列表）
    public function getUserAllGiveWinningsList($user_id, $time = []) {
        $sqlObj = Db::table('system_activity_bonus_log')->where('user_id', $user_id);
        if (!empty($time)) {
            $sqlObj->where('creatime_at', 'between', $time);
        }
        return $sqlObj->order('id','desc')->select();
    }
}