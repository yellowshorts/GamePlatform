<?php
namespace app\api\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;

class Parents extends Controller
{
    public function _success($type, $module, $msg = '10000', $result = '') {
        $message = lang($type.'_'.$module.'_'.$msg);
        return ['status' => 0, 'message' => $message, 'result' => $result, 'code' => $msg];
    }
    
    public function _error($type, $module, $msg = '10000', $result = '') {
        $message = lang($type.'_'.$module.'_'.$msg);
        return ['status' => 1, 'message' => $message, 'result' => $result, 'code' => $msg];
    }

    public function checkToken() {
        $isToken = $this->validate(['__token__'  => input('__token__'),],['__token__' => 'require|token',]);
        return $isToken;
    }

    public function check_login() {
        if (empty(Session::get('user_id'))) {
            return false;
        }
        return true;
    }
}