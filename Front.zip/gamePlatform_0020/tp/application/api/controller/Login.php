<?php
namespace app\api\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\api\controller\Parents;
use app\api\model\LoginModel;
use think\facade\Log;

class Login extends Parents
{
    public function login() {
        // $isToken = $this->checkToken();
        // if ($isToken !== true) {
        //     return $this->_error('check','params',10001);
        // }
        $login_params = input('post.');
        if (!check_params($login_params, ['user_name','password'])) {
            return $this->_error('check','params');
        }

        Log::write($login_params['user_name'],'login  login username');
        Log::write($login_params['password'],'login login  pwd');
        // 检测账号是否存在
        $loginModel = new LoginModel;
        $count = $loginModel->check_params(['user_name' => $login_params['user_name']]);
        if ($count == 0) {
            return $this->_error('check','login');
        }
        // 检测密码是否正确
        $userInfo = $loginModel->get_column(['user_id','password','salt','email','birthdate','phone','real_name','coin_type','account_status'],['user_name' => $login_params['user_name']]);
        if (md5($login_params['password'].''.$userInfo['salt']) != $userInfo['password']) {
            return $this->_error('check','login');
        }

        // 检测是否禁止登陆
        if ($userInfo['account_status'] == 1) {
            return $this->_error('check','login');
        }

        // 存入用户
        Session::set('user_id',$userInfo['user_id']);
        Session::set('user_info', [
            'email' => $userInfo['email'],
            'birthdate' => $userInfo['birthdate'],
            'phone' => $userInfo['phone'],
            'real_name' => $userInfo['real_name'],
            'coin_type' => $userInfo['coin_type'],
            'user_name' => $login_params['user_name'],
        ]);
        Cookie::set('user_login', ['user_name' => $login_params['user_name'], 'password' => $login_params['password']]);

        return $this->_success('check','success');
    }

    public function logout() {
        Session::delete('user_id');
        Session::delete('user_info');
        Cookie::delete('user_login');
        return $this->_success('check','success');
    }

    public function game_status() {
        $loginModel = new LoginModel;
        $userInfo = $loginModel->get_column(['game_status'],['user_id' => Session::get('user_id')]);
        if ($userInfo['game_status'] == 1) {
            return $this->_error('check','login');
        }
        return $this->_success('check','success');
    }
    
}