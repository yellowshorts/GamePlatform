<?php
namespace app\api\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\api\controller\Parents;

class Security extends Parents
{
     // 判断是否登录
     public function __construct() {
        parent::__construct();
        if (!$this->check_login()) {
            return $this->_error('check','login',10001);
        }
    }

    public function index() {
        $params = input('post.');
        $user_id = Session::get('user_id');
        return $this->{$params['action']}($params, $user_id);
    }

    public function editMobilePhone($params, $user_id) {
        Db::table('users')->update([
            'user_id' => $user_id,
            'phone' => $params['phone']
        ]);
        return $this->_success('check','success');
    }

    public function editEmail($params, $user_id) {
        Db::table('users')->update([
            'user_id' => $user_id,
            'email' => $params['email']
        ]);
        return $this->_success('check','success');
    }

    public function editLoginPassword($params, $user_id) {
        $salt = Db::table('users')->where('user_id', $user_id)->field('salt')->find()['salt'];
        $password = md5(md5($params['password']).''.$salt);
        Db::table('users')->update([
            'user_id' => $user_id,
            'password' => $password
        ]);
        return $this->_success('check','success');
    }

    public function editWithdrawalPassword($params, $user_id) {
        Db::table('users')->update([
            'user_id' => $user_id,
            'withdrawal_password' => md5($params['withdrawal_password'])
        ]);
        return $this->_success('check','success');
    }

    // 登录验证
    public function checkPass() {
        $user_id = Session::get('user_id');
        $pass = input('post.pass');
        $user_info = Db::table('users')->where('user_id', $user_id)->field('password, salt')->find();
        if (md5(md5($pass).''.$user_info['salt']) != $user_info['password']) {
            return $this->_error('check','login');
        }
        return $this->_success('check','success');
    }
}