<?php
namespace app\api\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use app\api\controller\Parents;
use app\api\model\RegisterModel;
use app\api\controller\Activity;
use app\api\model\VipModel;

class Register extends Parents
{
    // 注册账号
    public function register() {

        $register_params = input('post.');
        if (!check_params($register_params, ['user_name'])) {
            return $this->_error('check','params');
        }
        if ($register_params['password'] !== $register_params['confirm_password']) {
            return $this->_error('check','register',10003);
        }
        $registerModel = new RegisterModel;
        $count = $registerModel->check_params(['user_name' => $register_params['user_name']]);
        if ($count > 0) {
            return $this->_error('check','register');
        }
        $register_params['salt'] = generate_salt();
        $register_params['password'] = md5($register_params['password'].''.$register_params['salt']);
        $register_params['reg_time'] = date('Y-m-d H:i:s',time());
        $register_params['last_time'] = date('Y-m-d H:i:s',time());
        $register_params['pid'] = Session::get('pid');
        $register_params['area_code'] = 55;
        $register_params['ip'] = request()->ip();

        try {
            $user_id = $registerModel->add_register($register_params);
        } catch(\Exception  $e) {
            print_r($e);die;
            return $this->_error('check','mysql');
        }

        // 注册成功后 直接登录
        Session::set('user_id',$user_id);
        Cookie::set('user_login', ['user_name' => $register_params['user_name'], 'password' => $register_params['password']]);

        // 注册送彩金流程
        $activityCtrl = new Activity;
        $activityCtrl->flowControl(1);

        // 邀请注册送彩金流程
        if ($register_params['pid'] > 0) {
            $activityCtrl->flowControl(4);
            // 邀请注册升级VIP流程
            $vipModel = new VipModel;
            $vipModel->inviteNumberUpVipLevel(Session::get('user_id'));
        }

        return $this->_success('check','success');
    }

    // 注册检测
    public function check_params() {

        $register_params = input('post.');
        $registerModel = new RegisterModel;
    
        if (empty($register_params['user_name'])) {
            return $this->_error('check','params');
        }
        $count = $registerModel->check_params(['user_name' => $register_params['user_name']]);
        if ($count > 0) {
            return $this->_error('check','register');
        }
        return $this->_success('check','success');
        
    }
}