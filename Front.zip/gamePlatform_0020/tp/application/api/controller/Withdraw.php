<?php
namespace app\api\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\api\controller\Parents;

class Withdraw extends Parents
{
     // 判断是否登录
     public function __construct() {
        parent::__construct();
        if (!$this->check_login()) {
            return $this->_error('check','login',10001);
        }
    }

    // 保存pincode
    public function savePinCode() {
        $data = input('post.');
        if (!check_params($data, ['pincode'])) {
            return $this->_error('check','params');
        }
        Db::table('users')->where('user_id', Session::get('user_id'))->update([
            'withdrawal_password' => md5($data['pincode'])
        ]);
        return $this->_success('check','success');
    }

    // 保存代付信息
    public function saveWithdrawInfo() {
        $accountData = input('post.');
        if (!check_params($accountData, ['account_type','pix_account'])) {
            return $this->_error('check','params');
        }

        $cardNumber = Db::table('users')->where('user_id', Session::get('user_id'))->value('card_number');
        if (empty($cardNumber)) {
            if (empty($accountData['cpf_account'])) {
                return $this->_error('check','withdraw',10001);
            }
            $isCardNumber  =  Db::table('users')->where('card_number', $accountData['cpf_account'])->count();
            if ($isCardNumber > 0) {
                return $this->_error('check','withdraw',10000);
            }
            Db::table('users')->where('user_id', Session::get('user_id'))->update([
                'card_number' => $accountData['cpf_account']
            ]);
        }
        $userAccount = Db::table('users_account')->where('user_id',Session::get('user_id'))
                        ->where('account_type = :account_type OR account_number = :account_number', ['account_type' => $accountData['account_type'], 'account_number' => $accountData['pix_account']])
                        ->count();
        if ($userAccount > 0) {
            return $this->_error('check','withdraw',10002);
        }

        $isDefault = Db::table('users_account')->where('user_id',Session::get('user_id'))->count();
        $default = $isDefault == 0 ? 1 : 0;

        Db::table('users_account')->strict(false)->insert([
            'user_id' => Session::get('user_id'),
            'account_type' => $accountData['account_type'],
            'account_number' => $accountData['pix_account'],
            'default' => $default
        ]);

        return $this->_success('check','success');
    }

    // 更换默认账户类型
    public function default() {
        $data = input('post.');
        if (!check_params($data, ['id'])) {
            return $this->_error('check','params');
        }
        Db::table('users_account')->where('user_id', Session::get('user_id'))->update([
            'default' => 0
        ]);
        Db::table('users_account')->where('user_id', Session::get('user_id'))->where('id', $data['id'])->update([
            'default' => 1
        ]);
        return $this->_success('check','success');
    }
}