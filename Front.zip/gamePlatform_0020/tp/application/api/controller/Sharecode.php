<?php
namespace app\api\controller;
use think\Controller;
use think\facade\Session;

class Sharecode extends Parents
{
    public function index() {
        $url = input('get.url');
        $errorCorrectionLevel = 'H';//纠错级别：L、M、Q、H
        $matrixPointSize = 5;//二维码点的大小：1到10
        $QRcode = new \QRcode;
        $shareCodeName = 'static/shareCode/shareCode_'.Session::get('user_id').'.png';
        if (!file_exists($shareCodeName)) {
            $shareCode = $QRcode::png($url, $shareCodeName, $errorCorrectionLevel, $matrixPointSize, 2);
        }
        return ['status' => 0, 'result' => '/'. $shareCodeName, 'message' => 'ok'];
        // $im = imagecreatefrompng($shareCodeName);
        // header('Content-type: image/png');
        // imagepng($im);
        // imagedestroy($im);
        die;
    }
}
?>