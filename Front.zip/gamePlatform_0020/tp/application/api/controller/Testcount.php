<?php
namespace app\api\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\api\controller\Parents;

class Testcount extends Parents
{
    public function getUserList($limit = 30, $search = ''){
		// $dbobj = Db::table('admin_gameplatform_0020.users')->alias('u')
        //                 ->leftJoin('admin_gameplatform_0020.users pu','pu.user_id=u.pid');
		// if(trim($search) != ''){
		// 	$dbobj = $dbobj->where('u.user_id|u.user_name','like','%'.$search.'%');
		// }
        // $dbobj->field(['u.*' , 'pu.user_id as p_id', 'pu.user_name as p_name']);
		// $dbobj = $dbobj->order('u.user_id desc');
		// $dbobj = $dbobj->paginate($limit)->toArray();
		// foreach ($dbobj['data'] as $k => $v) {
		// 	// 代理数据
		// 	$agentData = $this->getAgentCount($v['user_id']);
		// }
		// print_r($dbobj['data']);
		// die;
		// return $dbobj;
		$agentData = $this->getAgentCount(14);
		print_r($agentData);
		die;
	}

	public function getAgentCount($user_id, $agentData = [
		'level' => 1,
		'level_format' => [1 => 'one', 2 => 'two', 3 => 'three'],
		'one_number' => 0,
		'one_payment_number' => 0,
		'one_payment_total' => 0,
		'two_number' => 0,
		'two_payment_number' => 0,
		'two_payment_total' => 0,
		'three_number' => 0,
		'three_payment_number' => 0,
		'three_payment_total' => 0,
	]) {
		$result = Db::query("SELECT u.user_id, pay.paymentNumber, pay.amounTotal FROM admin_gameplatform_0020.users u 
							LEFT JOIN (SELECT pay.uid, COUNT(1) AS paymentNumber, SUM(fee) AS amounTotal FROM ym_manage.paylog pay
							WHERE pay.`status` = 1 AND pay.type = 3 GROUP BY pay.uid) pay ON u.user_id = pay.uid
							WHERE u.pid = '{$user_id}'");
		$agentData[$agentData['level_format'][$agentData['level']].'_number'] = count($result);
		foreach ($result as $k => $v) {
			if (!empty($v['paymentNumber'])) {
				$agentData[$agentData['level_format'][$agentData['level']].'_payment_number'] += 1;
				$agentData[$agentData['level_format'][$agentData['level']].'_payment_total'] += $v['amounTotal'];
			}
		}

		if (count($result) == 0 || $agentData['level'] == 3) {
			return $agentData;
		}

		$agentData['level'] += 1;

		foreach ($result as $k => $v) {
			return $this->getAgentCount($v['user_id'], $agentData);
		}
	}

	public function getUserPaymentTotal($user_id) {
		$rs = Db::table('ym_manage.paylog')->where('uid', $user_id)->where('status', 1)->field('fee, type')->select();
		$data = [
			'paymentNumber' => 0,
			'paymentTotal' => 0,
			'withdrawTotal' => 0
		];
		foreach ($rs as $k => $v) {
			$data['paymentNumber'] += 1;
			if ($v['type'] == 3) {
				$data['paymentTotal'] += $v['fee'];
			}
			if ($v['type'] == 99) {
				$data['withdrawTotal'] += $v['fee'];
			}
		}
		return $data;
	}
}