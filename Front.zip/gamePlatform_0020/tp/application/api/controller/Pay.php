<?php
namespace app\api\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use think\Db;
use think\facade\Request;
use app\api\controller\Parents;
use app\api\model\PayModel;
use app\api\model\LoginModel;
use app\api\model\UserModel;
use app\api\model\GameUserModel;
use app\api\model\PlayerModel;
use app\api\model\VipModel;
use app\api\controller\Activity;
use app\api\controller\ShareStatistics;

class Pay extends Parents
{
    static $fastPay = [
        'key' => '327271ad90e23aa90ad2c6c05852e936',
        'payUrl' => 'http://www.fast-pay.cc/gateway.aspx',
        'params' => [
            'pay' => [
                'mer_no' => '1003441',
                'order_no' => '',
                'order_amount' => 0,
                'payname' => '',
                'payemail' => '',
                'payphone' => '',
                'currency' => 'BRL',
                'paytypecode' => '18001',
                'method' => 'trade.create',
                'returnurl' => '/api/Pay/callbackfastpay',
            ],
            'withdrawPay' => [
                'mer_no' => '1003441',
                'order_no' => '',
                'method' => 'fund.apply',
                'order_amount' => 0,
                'currency' => 'BRL',
                'acc_code' => '18001',
                'acc_name' => '',
                'acc_no' => '',
                'returnurl' => '/api/Pay/callbackwithdrawalfastpay',
            ]
        ],
    ];
    
    static $wakapay = [
        'key' => 'ed4c67326012e2502012b031e5f8ecb3',
        'payUrl' => 'https://wakapayplus.com/gateway/',
        'params' => [
            'pay' => [
                'mer_no' => '8691503',
                'order_no' => '',
                'order_amount' => 0,
                'payname' => '',
                'payemail' => '',
                'payphone' => '',
                'currency' => 'BRL',
                'paytypecode' => '18002',
                'method' => 'trade.create',
                'returnurl' => '/api/Pay/callbackwakapay',
            ],
            'withdrawPay' => [
                'mer_no' => '8691503',
                'order_no' => '',
                'method' => 'fund.apply',
                'order_amount' => 0,
                'currency' => 'BRL',
                'acc_code' => '18002',
                'acc_name' => '',
                'acc_no' => '',
                'returnurl' => '/api/Pay/callbackwithdrawalwakapay',
            ]
        ],
    ];
    
    
    static $kppay = [
        'key' => 'fxjoyIhJYkCmGiOBNlutWsQTbavgMzHU',
        'payUrl' => 'https://pp.kppay.live/api/version1/pay',
        'payWithdrawUrl' => 'https://pp.kppay.live/api/version1/payout',
        'params' => [
            'pay' => [
                'merchantId' => '20230746',
                'orderNo' => '',
                'amount' => 0,
                'channelId' => 'QGB',
                'name' => '',
                'email' => '',
                'mobile' => '',
                'payType' => 'PIX',
                'payNumber' => '',
                'notifyUrl' => '/api/Pay/callbackkppay',
                'returnUrl' => '',
            ],
            'withdrawPay' => [
                'merchantId' => '20230746',
                'channelId' => 'QGB',
                'orderNo' => '',
                'amount' => 0,
                'payType' => 'PIX_PHONE',
                'email' => '',
                'name' => '',
                'mobile' => '',
                'cardNumber' => '',
                'notifyUrl' => '/api/Pay/callbackwithdrawalkppay',
            ]
        ],
    ];

    static $testpay = [
        'key' => 'fxjoyIhJYkCmGiOBNlutWsQTbavgMzHU',
        'payUrl' => 'http://127.0.0.1/pay',
        'payWithdrawUrl' => 'https://pp.kppay.live/api/version1/payout',
        'params' => [
            'pay' => [
                'merchantId' => '20230746',
                'orderNo' => '',
                'amount' => 0,
                'channelId' => 'QGB',
                'name' => '',
                'email' => '',
                'mobile' => '',
                'payType' => 'PIX',
                'payNumber' => '',
                'notifyUrl' => '/api/Pay/callbacktestppay',
                'returnUrl' => '',
            ],
            'withdrawPay' => [
                'merchantId' => '20230746',
                'channelId' => 'QGB',
                'orderNo' => '',
                'amount' => 0,
                'payType' => 'PIX_PHONE',
                'email' => '',
                'name' => '',
                'mobile' => '',
                'cardNumber' => '',
                'notifyUrl' => '/api/Pay/callbackwithdrawalkppay',
            ]
        ],
    ];
    
    

    // 判断是否登录
    public function __construct() {
        parent::__construct();
        if (!$this->check_login()) {
            return $this->_error('check','login',10001);
        }
    }

    // 支付 / 提现
    public function index() {
        $type = input('post.type');
        $payname = Db::table('ym_manage.config')->where('id',23)->value('value');

        if ($type == 'payment') {
            return $this->testpay(); //fuck you 支付订单测试
            // return $this->{$payname}(); 
        }
        if ($type == 'withdrawal') {
            return $this->withdrawaltestpay();
            // return $this->{'withdrawal'.$payname}(); //fuck you 
        }
    }

    // testpay 支付
    public function testpay() {

        $post = input('post.');
        $money = 0;
        $paymentType = 3;

        if ($post['type'] == 'payment') {
            $payModel = new PayModel;
            $giftInfo = $payModel->getPaymentList(intval($post['gift_id']));
            $money = intval($giftInfo['recharge_money']);
            if (empty($giftInfo['id'])) {
                return $this->_error('check','pay',10000);
            }
        }
        if ($post['type'] == 'vip') {
            $money = intval($post['money']);
            $paymentType = 4;
            $post['gift_id'] = 0;
        }

        $header = [
            'Content-Type: application/json',
        ];
        

        $params = self::$kppay['params']['pay'];
        $params['orderNo'] = getOrderId();
        $params['amount'] = $money.'.00';
        $params['name'] = Session::get('user_info')['real_name'];
        $params['email'] = 'xxxx@xxx.com';
        $params['mobile'] = Session::get('user_info')['real_name'];
        $params['payNumber'] = '8888888';
        $params['notifyUrl'] = config('app_host').$params['notifyUrl'];
        $params['returnUrl'] = config('app_host');
        $params['sign'] = strtoupper($this->sign($this->ASCII($params),self::$kppay['key']));

        try {
            Db::connect('db_YmManage')->table('paylog')->insert([
                    'uid' => Session::get('user_id'),
                    'fee' => $params['amount'],
                    'type' => $paymentType,
                    'osn' => $params['orderNo'],
                    'createtime' => time(),
                    'paytime' => time(),
                    'payname' => 'testpay',
                    'gift_id' =>intval($post['gift_id']),
                    'status' => 0,
                    'payresmsg' => '',
                    'prepayresmsg' => 'test',
                    'payendtime' => time(),
            ]);
            return ['status' => 0, 'message' => 'ok', 'result' => ['order_no' => 'payOrderId123123123123' , 'url' => '/api/Pay/callbacktestppay']];
        } catch(\Exception $e) {
            return ['status' => 1, 'message' => $e->getMessage(), 'result' => ''];
        }
        die;
    }

    // testpay 支付回调
    public function callbacktestppay() {

        $osn = 'merOrderNo';  //$notify_params['merOrderNo']
        $amount = 10; //$notify_params['amount']
        $notify_params = 'notify_params';
        // 判断订单是否存在
        $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $osn)->find();
        if (!empty($paylog) && $paylog['callbacknum'] == 0) {
            Db::connect('db_YmManage')->table('paylog')->where('osn', $osn)->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
            if ($paylog['type'] == 3) {
                Db::table('users')->where('user_id', $paylog['uid'])->inc('brl_wallet', $amount)->update();
                $activityCtrl = new Activity;
                $activityCtrl->flowControl(2, $paylog['uid']);
            }
            if ($paylog['type'] == 4) {
                $vipModel = new VipModel;
                $vipModel->addUserVip($paylog['uid']);
            }
            die('success');
        }

        // $notify_params = Request::post();
        // if ($notify_params['status'] == 1) {
        //     $notify_sign = strtoupper($notify_params['sign']);
        //     unset($notify_params['sign']);
        //     $sign = strtoupper($this->sign($this->ASCII($notify_params),self::$kppay['key']));
        //     if ($sign == $notify_sign) {
               
        //     }
        //     echo 'success';
        // }
    }
    // withdrawaltestpay 代付
    public function withdrawaltestpay() {

        $post = input('post.');
        $begin_time = strtotime(date('Y-m-01 00:00:00'));
        $end_time = strtotime(date('Y-m-t 23:59:59'));
        $userModel = new UserModel;
        $payModel = new PayModel;
        $ShareStatisticsCtrl = new ShareStatistics;
        $gameUserModel = new GameUserModel;
        $vipModel = new VipModel;
        $vip_level = $vipModel->getUserVip(Session::get('user_id'));
        $vip_info  = $vipModel->getVipList($vip_level);
        $withdrawLimit = $payModel->getWithdrawLimit();
        $userAccount = $userModel->getUserAccount($post['account_id'], Session::get('user_id'));
        $withdrawTotal = $payModel->getPaymentUserList(Session::get('user_id'), 1, 'total', 'COUNT(1) as withdrawTotal', 99, [$begin_time, $end_time])['withdrawTotal'];
        $users = $userModel->getUser(Session::get('user_id'));
        
        $params = self::$kppay['params']['withdrawPay'];
        $params['orderNo'] = getOrderId();
        $params['amount'] = $post['money'];
        $params['email'] = 'xxxx@xxxx.com';
        $params['name'] = Session::get('user_info')['real_name'];
        $params['mobile'] = $users['phone'];
        $params['cardNumber'] = $userAccount['account_number'];
        $params['notifyUrl'] = config('app_host').$params['notifyUrl'];
        $params['sign'] = strtoupper($this->sign($this->ASCII($params),self::$kppay['key']));

         // 检查是否有手续费, 如果有 扣除手续费再提现
         $commission = 0;
         // 如果当前VIP 没有免费提现权限 或者 提现次数大于0 
         if($vip_info['withdraw_privilege_free_number'] < 0 || $withdrawTotal > 0)  {
             // 提现手续费 是否大于 0
             if ($vip_info['withdraw_privilege_commission'] > 0) {
                 $commission = $params['amount'] * ($vip_info['withdraw_privilege_commission'] / 100);
                 $params['amount'] = intval($params['amount'] - $commission);
             }
         }
         
        $header = [
            'Content-Type: application/json',
        ];

        Db::connect('db_YmManage')->table('user_exchange')->insert([
            'user_id' => Session::get('user_id'),
            'order_number' => $params['orderNo'] ,
            'bank_number' => $params['cardNumber'] ,
            'real_name' => $params['name'] ,
            'bank_open' => $params['mobile'] ,
            'money' => $params['amount'].'.00' ,
            'pay_type' => 'kppay',
            'commission_percentage' => $vip_info['withdraw_privilege_commission'],
            'commission' => $commission,
            'email' => '',
            'phone' => '',
            'status' => 0 ,
            'withdraw_code' => json_encode($params),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Db::table('users')->where('user_id', Session::get('user_id'))->dec('brl_wallet', intval($post['money']))->update();
        return $this->_success('check','success');
    }
    
    // kppay支付
    public function kppay() {

        $post = input('post.');

        $money = 0;
        $paymentType = 3;

        if ($post['type'] == 'payment') {
            $payModel = new PayModel;
            $giftInfo = $payModel->getPaymentList(intval($post['gift_id']));
            $money = intval($giftInfo['recharge_money']);
            if (empty($giftInfo['id'])) {
                return $this->_error('check','pay',10000);
            }
        }
        if ($post['type'] == 'vip') {
            $money = intval($post['money']);
            $paymentType = 4;
            $post['gift_id'] = 0;
        }

        $header = [
            'Content-Type: application/json',
        ];
        

        $params = self::$kppay['params']['pay'];
        $params['orderNo'] = getOrderId();
        $params['amount'] = $money.'.00';
        $params['name'] = Session::get('user_info')['real_name'];
        $params['email'] = 'xxxx@xxx.com';
        $params['mobile'] = Session::get('user_info')['real_name'];
        $params['payNumber'] = '8888888';
        $params['notifyUrl'] = config('app_host').$params['notifyUrl'];
        $params['returnUrl'] = config('app_host');
        $params['sign'] = strtoupper($this->sign($this->ASCII($params),self::$kppay['key']));

        $depositResult = PayModel::PostData(self::$kppay['payUrl'], json_encode($params), $header);
        $depositResult = json_decode($depositResult,true);
        if ($depositResult['code'] == 1) {
            try {
                Db::connect('db_YmManage')->table('paylog')->insert([
                        'uid' => Session::get('user_id'),
						'fee' => $params['amount'],
						'type' => $paymentType,
						'osn' => $params['orderNo'],
						'createtime' => time(),
						'paytime' => time(),
                        'payname' => 'kppay',
                        'gift_id' =>intval($post['gift_id']),
						'status' => 0,
						'payresmsg' => '',
						'prepayresmsg' => json_encode($depositResult),
						'payendtime' => time(),
                ]);
                return ['status' => 0, 'message' => 'ok', 'result' => ['order_no' => $depositResult['data']['merOrderNo'] , 'url' => $depositResult['data']['payUrl']]];
            } catch(\Exception $e) {
                return ['status' => 1, 'message' => $e->getMessage(), 'result' => ''];
            }
        } else {
            return ['status' => 1, 'message' => $depositResult['msg'], 'result' => ''];
        }
        die;
    }

    // fastpay支付
    public function fastpay() {

        $post = input('post.');

        $money = 0;
        $paymentType = 3;

        if ($post['type'] == 'payment') {
            $payModel = new PayModel;
            $giftInfo = $payModel->getPaymentList(intval($post['gift_id']));
            $money = intval($giftInfo['recharge_money']);
            if (empty($giftInfo['id'])) {
                return $this->_error('check','pay',10000);
            }
        }
        if ($post['type'] == 'vip') {
            $money = intval($post['money']);
            $paymentType = 4;
            $post['gift_id'] = 0;
        }

        $header = [
            'Content-Type: application/json',
        ];
        

        $params = self::$fastPay['params']['pay'];
        $params['order_no'] = getOrderId();
        $params['order_amount'] = $money.'.00';
        $params['payname'] = Session::get('user_info')['real_name'];
        $params['payemail'] = Session::get('user_info')['real_name'];
        $params['payphone'] = Session::get('user_info')['real_name'];
        $params['returnurl'] = config('app_host').$params['returnurl'];
        $params['sign'] = $this->signx($this->ASCII($params),self::$fastPay['key']);

        $depositResult = PayModel::PostData(self::$fastPay['payUrl'], json_encode($params), $header);
        $depositResult = json_decode($depositResult,true);
        if ($depositResult['status'] == 'success') {
            try {
                Db::connect('db_YmManage')->table('paylog')->insert([
                        'uid' => Session::get('user_id'),
						'fee' => $params['order_amount'],
						'type' => $paymentType,
						'osn' => $params['order_no'],
						'createtime' => time(),
						'paytime' => time(),
                        'payname' => 'fastpay',
                        'gift_id' =>intval($post['gift_id']),
						'status' => 0,
						'payresmsg' => '',
						'prepayresmsg' => json_encode($depositResult),
						'payendtime' => time(),
                ]);
                return ['status' => 0, 'message' => 'ok', 'result' => ['order_no' => $depositResult['order_no'] , 'url' => $depositResult['order_data']]];
            } catch(\Exception $e) {
                return ['status' => 1, 'message' => $e->getMessage(), 'result' => ''];
            }
        } else {
            return ['status' => 1, 'message' => $depositResult['status_mes'], 'result' => ''];
        }
        die;
    }

     // wakapay支付
     public function wakapay() {

        $post = input('post.');

        $money = 0;
        $paymentType = 3;

        if ($post['type'] == 'payment') {
            $payModel = new PayModel;
            $giftInfo = $payModel->getPaymentList(intval($post['gift_id']));
            $money = intval($giftInfo['recharge_money']);
            if (empty($giftInfo['id'])) {
                return $this->_error('check','pay',10000);
            }
        }
        if ($post['type'] == 'vip') {
            $money = intval($post['money']);
            $paymentType = 4;
            $post['gift_id'] = 0;
        }

        $header = [
            'Content-Type: application/json',
        ];
        

        $params = self::$wakapay['params']['pay'];
        $params['order_no'] = getOrderId();
        $params['order_amount'] = $money.'.00';
        $params['payname'] = Session::get('user_info')['real_name'];
        $params['payemail'] = Session::get('user_info')['real_name'];
        $params['payphone'] = Session::get('user_info')['real_name'];
        $params['returnurl'] = config('app_host').$params['returnurl'];
        $params['sign'] = $this->signx($this->ASCII($params),self::$wakapay['key']);

        $depositResult = PayModel::PostData(self::$wakapay['payUrl'], json_encode($params), $header);
        $depositResult = json_decode($depositResult,true);
        if ($depositResult['status'] == 'success') {
            try {
                Db::connect('db_YmManage')->table('paylog')->insert([
                        'uid' => Session::get('user_id'),
						'fee' => $params['order_amount'],
						'type' => $paymentType,
						'osn' => $params['order_no'],
						'createtime' => time(),
						'paytime' => time(),
                        'payname' => 'wakapay',
                        'gift_id' =>intval($post['gift_id']),
						'status' => 0,
						'payresmsg' => '',
						'prepayresmsg' => json_encode($depositResult),
						'payendtime' => time(),
                ]);
                return ['status' => 0, 'message' => 'ok', 'result' => ['order_no' => $depositResult['order_no'] , 'url' => $depositResult['order_data']]];
            } catch(\Exception $e) {
                return ['status' => 1, 'message' => $e->getMessage(), 'result' => ''];
            }
        } else {
            return ['status' => 1, 'message' => $depositResult['status_mes'], 'result' => ''];
        }
        die;
    }
    
    // kppay 支付回调
    public function callbackkppay() {
        $notify_params = Request::post();
        if ($notify_params['status'] == 1) {
            $notify_sign = strtoupper($notify_params['sign']);
            unset($notify_params['sign']);
            $sign = strtoupper($this->sign($this->ASCII($notify_params),self::$kppay['key']));
            if ($sign == $notify_sign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['merOrderNo'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['merOrderNo'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
                    if ($paylog['type'] == 3) {
                        Db::table('users')->where('user_id', $paylog['uid'])->inc('brl_wallet', $notify_params['amount'])->update();
                        $activityCtrl = new Activity;
                        $activityCtrl->flowControl(2, $paylog['uid']);
                    }
                    if ($paylog['type'] == 4) {
                        $vipModel = new VipModel;
                        $vipModel->addUserVip($paylog['uid']);
                    }
                    die('success');
                }
            }
            echo 'success';
        }
    }

    // fastpay 支付回调
    public function callbackfastpay() {
        $notify_params = Request::post();
        if ($notify_params['status'] == 'success') {
            $notify_sign = $notify_params['sign'];
            unset($notify_params['sign']);
            $sign =$this->signx($this->ASCII($notify_params),self::$fastPay['key']);
            if ($sign == $notify_sign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
                    if ($paylog['type'] == 3) {
                        Db::table('users')->where('user_id', $paylog['uid'])->inc('brl_wallet', $notify_params['order_amount'])->update();
                        $activityCtrl = new Activity;
                        $activityCtrl->flowControl(2, $paylog['uid']);
                    }
                    if ($paylog['type'] == 4) {
                        $vipModel = new VipModel;
                        $vipModel->addUserVip($paylog['uid']);
                    }
                    die('ok');
                }
            }
            echo 'ok';
        }
    }

    // wakapay 支付回调
    public function callbackwakapay() {
        $notify_params = Request::post();
        if ($notify_params['status'] == 'success') {
            $notify_sign = $notify_params['sign'];
            unset($notify_params['sign']);
            $sign =$this->signx($this->ASCII($notify_params),self::$wakapay['key']);
            if ($sign == $notify_sign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
                    if ($paylog['type'] == 3) {
                        Db::table('users')->where('user_id', $paylog['uid'])->inc('brl_wallet', $notify_params['order_amount'])->update();
                        $activityCtrl = new Activity;
                        $activityCtrl->flowControl(2, $paylog['uid']);
                    }
                    if ($paylog['type'] == 4) {
                        $vipModel = new VipModel;
                        $vipModel->addUserVip($paylog['uid']);
                    }
                    die('ok');
                }
            }
            echo 'ok';
        }
    }
    
     // kppay 代付
    public function withdrawalkppay() {

        $post = input('post.');
        $begin_time = strtotime(date('Y-m-01 00:00:00'));
        $end_time = strtotime(date('Y-m-t 23:59:59'));
        $userModel = new UserModel;
        $payModel = new PayModel;
        $ShareStatisticsCtrl = new ShareStatistics;
        $gameUserModel = new GameUserModel;
        $vipModel = new VipModel;
        $vip_level = $vipModel->getUserVip(Session::get('user_id'));
        $vip_info  = $vipModel->getVipList($vip_level);
        $withdrawLimit = $payModel->getWithdrawLimit();
        $userAccount = $userModel->getUserAccount($post['account_id'], Session::get('user_id'));
        $withdrawTotal = $payModel->getPaymentUserList(Session::get('user_id'), 1, 'total', 'COUNT(1) as withdrawTotal', 99, [$begin_time, $end_time])['withdrawTotal'];
        $users = $userModel->getUser(Session::get('user_id'));
        
        $params = self::$kppay['params']['withdrawPay'];
        $params['orderNo'] = getOrderId();
        $params['amount'] = $post['money'];
        $params['email'] = 'xxxx@xxxx.com';
        $params['name'] = Session::get('user_info')['real_name'];
        $params['mobile'] = $users['phone'];
        $params['cardNumber'] = $userAccount['account_number'];
        $params['notifyUrl'] = config('app_host').$params['notifyUrl'];
        $params['sign'] = strtoupper($this->sign($this->ASCII($params),self::$kppay['key']));

         // 检查是否有手续费, 如果有 扣除手续费再提现
         $commission = 0;
         // 如果当前VIP 没有免费提现权限 或者 提现次数大于0 
         if($vip_info['withdraw_privilege_free_number'] < 0 || $withdrawTotal > 0)  {
             // 提现手续费 是否大于 0
             if ($vip_info['withdraw_privilege_commission'] > 0) {
                 $commission = $params['amount'] * ($vip_info['withdraw_privilege_commission'] / 100);
                 $params['amount'] = intval($params['amount'] - $commission);
             }
         }
         
         $header = [
            'Content-Type: application/json',
        ];

        Db::connect('db_YmManage')->table('user_exchange')->insert([
            'user_id' => Session::get('user_id'),
            'order_number' => $params['orderNo'] ,
            'bank_number' => $params['cardNumber'] ,
            'real_name' => $params['name'] ,
            'bank_open' => $params['mobile'] ,
            'money' => $params['amount'].'.00' ,
            'pay_type' => 'kppay',
            'commission_percentage' => $vip_info['withdraw_privilege_commission'],
            'commission' => $commission,
            'email' => '',
            'phone' => '',
            'status' => 0 ,
            'withdraw_code' => json_encode($params),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Db::table('users')->where('user_id', Session::get('user_id'))->dec('brl_wallet', intval($post['money']))->update();
        return $this->_success('check','success');
    }

    // fastpay 代付
    public function withdrawalfastpay() {

        $post = input('post.');
        $begin_time = strtotime(date('Y-m-01 00:00:00'));
        $end_time = strtotime(date('Y-m-t 23:59:59'));
        $userModel = new UserModel;
        $payModel = new PayModel;
        $ShareStatisticsCtrl = new ShareStatistics;
        $gameUserModel = new GameUserModel;
        $vipModel = new VipModel;
        $vip_level = $vipModel->getUserVip(Session::get('user_id'));
        $vip_info  = $vipModel->getVipList($vip_level);
        $withdrawLimit = $payModel->getWithdrawLimit();
        $userAccount = $userModel->getUserAccount($post['account_id'], Session::get('user_id'));
        $withdrawTotal = $payModel->getPaymentUserList(Session::get('user_id'), 1, 'total', 'COUNT(1) as withdrawTotal', 99, [$begin_time, $end_time])['withdrawTotal'];

        $params = self::$fastPay['params']['withdrawPay'];
        $params['order_no'] = getOrderId();
        $params['order_amount'] = $post['money'];
        $params['acc_name'] = Session::get('user_info')['real_name'];
        $params['acc_no'] = $userAccount['account_number'];
        $params['returnurl'] = config('app_host').$params['returnurl'];
        $params['sign'] = $this->signx($this->ASCII($params),self::$fastPay['key']);

         // 检查是否有手续费, 如果有 扣除手续费再提现
         $commission = 0;
         // 如果当前VIP 没有免费提现权限 或者 提现次数大于0 
         if($vip_info['withdraw_privilege_free_number'] < 0 || $withdrawTotal > 0)  {
             // 提现手续费 是否大于 0
             if ($vip_info['withdraw_privilege_commission'] > 0) {
                 $commission = $params['order_amount'] * ($vip_info['withdraw_privilege_commission'] / 100);
                 $params['order_amount'] = intval($params['order_amount'] - $commission);
             }
         }

        Db::connect('db_YmManage')->table('user_exchange')->insert([
            'user_id' => Session::get('user_id'),
            'order_number' => $params['order_no'] ,
            'bank_number' => $params['acc_no'] ,
            'real_name' => $params['acc_name'] ,
            'bank_open' => $params['acc_code'] ,
            'money' => $params['order_amount'].'.00' ,
            'pay_type' => 'fastpay',
            'commission_percentage' => $vip_info['withdraw_privilege_commission'],
            'commission' => $commission,
            'email' => '',
            'phone' => '',
            'status' => 0 ,
            'withdraw_code' => json_encode($params),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Db::table('users')->where('user_id', Session::get('user_id'))->dec('brl_wallet', intval($post['money']))->update();
        return $this->_success('check','success');
    }

    // wakapay 代付
    public function withdrawalwakapay() {

        $post = input('post.');
        $begin_time = strtotime(date('Y-m-01 00:00:00'));
        $end_time = strtotime(date('Y-m-t 23:59:59'));
        $userModel = new UserModel;
        $payModel = new PayModel;
        $ShareStatisticsCtrl = new ShareStatistics;
        $gameUserModel = new GameUserModel;
        $vipModel = new VipModel;
        $vip_level = $vipModel->getUserVip(Session::get('user_id'));
        $vip_info  = $vipModel->getVipList($vip_level);
        $withdrawLimit = $payModel->getWithdrawLimit();
        $userAccount = $userModel->getUserAccount($post['account_id'], Session::get('user_id'));
        $withdrawTotal = $payModel->getPaymentUserList(Session::get('user_id'), 1, 'total', 'COUNT(1) as withdrawTotal', 99, [$begin_time, $end_time])['withdrawTotal'];

        $params = self::$wakapay['params']['withdrawPay'];
        $params['order_no'] = getOrderId();
        $params['order_amount'] = $post['money'];
        $params['acc_name'] = Session::get('user_info')['real_name'];
        $params['acc_no'] = $userAccount['account_number'];
        $params['returnurl'] = config('app_host').$params['returnurl'];
        $params['sign'] = $this->signx($this->ASCII($params),self::$wakapay['key']);

         // 检查是否有手续费, 如果有 扣除手续费再提现
         $commission = 0;
         // 如果当前VIP 没有免费提现权限 或者 提现次数大于0 
         if($vip_info['withdraw_privilege_free_number'] < 0 || $withdrawTotal > 0)  {
             // 提现手续费 是否大于 0
             if ($vip_info['withdraw_privilege_commission'] > 0) {
                 $commission = $params['order_amount'] * ($vip_info['withdraw_privilege_commission'] / 100);
                 $params['order_amount'] = intval($params['order_amount'] - $commission);
             }
         }

        Db::connect('db_YmManage')->table('user_exchange')->insert([
            'user_id' => Session::get('user_id'),
            'order_number' => $params['order_no'] ,
            'bank_number' => $params['acc_no'] ,
            'real_name' => $params['acc_name'] ,
            'bank_open' => $params['acc_code'] ,
            'money' => $params['order_amount'].'.00' ,
            'pay_type' => 'wakapay',
            'commission_percentage' => $vip_info['withdraw_privilege_commission'],
            'commission' => $commission,
            'email' => '',
            'phone' => '',
            'status' => 0 ,
            'withdraw_code' => json_encode($params),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Db::table('users')->where('user_id', Session::get('user_id'))->dec('brl_wallet', intval($post['money']))->update();
        return $this->_success('check','success');
    }

    // 后台同意提现
    public function adminwithdrawalpay() {
        $post = input('post.');
        if ($post['payname'] == 'fastpay') {
            $url = self::$fastPay['payUrl'];
        }
        if ($post['payname'] == 'wakapay') {
            $url = self::$wakapay['payUrl'];
        }
        if ($post['payname'] == 'kppay') {
            $url = self::$kppay['payWithdrawUrl'];
        }
        $payInfo =  Db::connect('db_YmManage')->table('user_exchange')->where('id', $post['id'])->where('status', 0)->find();
        $withdraw_code = json_decode($payInfo['withdraw_code'],true);
        $header = ['Content-Type: application/json'];
        $withdrawResult = PayModel::PostData($url, json_encode($withdraw_code), $header);
        $withdrawResult = json_decode($withdrawResult,true);
        if ($post['payname'] == 'kppay') {
            $status = $withdrawResult['code'] == 1 ? 'success' : '';
        } else {
            $status = $withdrawResult['status'];
        }
        if ($status == 'success') {
            Db::connect('db_YmManage')->table('paylog')->insert([
                'uid' => $payInfo['user_id'],
                'fee' => $payInfo['money'],
                'type' => 99,
                'osn' => $payInfo['order_number'],
                'createtime' => time(),
                'paytime' => time(),
                'payname' => $payInfo['pay_type'],
                'status' => 0,
                'payresmsg' => '',
                'prepayresmsg' => json_encode($withdrawResult),
                'payendtime' => time(),
            ]);
            return ['status' => 0, 'message' => 'ok', 'result' => $withdrawResult];
        } else {
            if ($post['payname'] == 'kppay') {
                $msg = $withdrawResult['msg'];
            } else {
                $msg = $withdrawResult['status_mes'];
            }
            return ['status' => 1, 'message' => $msg, 'result' => ''];
        }
    }

    // 后台拒绝提现
    public function adminwithdrawalpayno() {
        $post = input('post.');
        $payInfo =  Db::connect('db_YmManage')->table('user_exchange')->where('id', $post['id'])->where('status', 0)->find();
        Db::table('users')->where('user_id', $payInfo['user_id'])->inc('brl_wallet', $payInfo['money'])->update();
    }
    
     // kppay 提现回调
    public function callbackwithdrawalkppay() {
        $notify_params = Request::post();
        if ($notify_params['status'] == 1) {
            $notify_sign = strtoupper($notify_params['sign']);
            unset($notify_params['sign']);
            $sign = strtoupper($this->sign($this->ASCII($notify_params),self::$kppay['key']));
            if ($sign == $notify_sign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['merOrderNo'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['merOrderNo'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
                    Db::connect('db_YmManage')->table('user_exchange')->where('order_number', $notify_params['merOrderNo'])->update(['status' => 1]);
                    die('success');
                }
            }
        }
    }

    // fastpay 提现回调
    public function callbackwithdrawalfastpay() {
        $notify_params = Request::post();
        if ($notify_params['result'] == 'success') {
            $notify_sign = $notify_params['sign'];
            unset($notify_params['sign']);
            $sign =$this->signx($this->ASCII($notify_params),self::$fastPay['key']);
            if ($sign == $notify_sign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
                    Db::connect('db_YmManage')->table('user_exchange')->where('order_number', $notify_params['order_no'])->update(['status' => 1]);
                    die('ok');
                }
            }
        }
    }

    // wakapay 提现回调
    public function callbackwithdrawalwakapay() {
        $notify_params = Request::post();
        if ($notify_params['result'] == 'success') {
            $notify_sign = $notify_params['sign'];
            unset($notify_params['sign']);
            $sign =$this->signx($this->ASCII($notify_params),self::$wakapay['key']);
            if ($sign == $notify_sign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $notify_params['order_no'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($notify_params), 'payendtime' => time()]);
                    Db::connect('db_YmManage')->table('user_exchange')->where('order_number', $notify_params['order_no'])->update(['status' => 1]);
                    die('ok');
                }
            }
        }
    }

    public function signx($signSource, $key) {
        if (!empty($key)) {
            $signSource = $signSource.$key;
        }
       return md5($signSource);
    }
    
    public function sign($signSource,$key) {
        if (!empty($key)) {
             $signSource = $signSource."&key=".$key;
        }
        return md5($signSource);
    }

    public function ASCII($params = array()){
        if(!empty($params)){
           $p =  ksort($params);
           if($p){
               $str = '';
               foreach ($params as $k=>$val){
                   $str .= $k .'=' . $val . '&';
               }
               $strs = rtrim($str, '&');
               return $strs;
           }
        }
        return '参数错误';
    }

}