<?php
namespace app\api\controller;
use think\Controller;
use think\facade\Cookie;
use think\facade\Session;
use think\Db;
use think\facade\Request;
use app\api\controller\Parents;
use app\api\model\AupayModel;
use app\api\model\LoginModel;
use app\api\model\UserModel;
use app\api\model\GameUserModel;
use app\api\model\PlayerModel;
use app\api\model\VipModel;
use app\api\controller\Activity;
use app\api\controller\ShareStatistics;

class Aupay extends Parents
{
    // 商户号
    static $memberid = '10007';
    // 代收URL
    static $paymentUrl = 'https://api.mercadosuperfast.com/api/payment.html';

    // MD5 KEY
    static $md5Key = '5U4ZCLP9TX1FIJOG1E';

    // 代付URL
    static $payoutUrl = 'https://api.mercadosuperfast.com/api/payout.html';

    // 支付回调URL
    static $payNotifyUrl = '/api/Aupay/callbackpay';

    // 代付回调URL
    static $withdrawNotifyUrl = '/api/Aupay/callbackwithdrawalpay';

    // 判断是否登录
    public function __construct() {
        parent::__construct();
        if (!$this->check_login()) {
            return $this->_error('check','login',10001);
        }
    }

    /**
     * 轮训是否支付成功
     */
    public function checkPayStatus() {
        $transaction_id = input('post.transaction_id');
        $pay = Db::connect('db_YmManage')->table('paylog')
            ->where('osn', $transaction_id)
            ->where('status',1)
            ->count();
        return $this->_success('check','success',10000,$pay);
    }

    /**
     * 获取钱包余额
     */
    public function getAmount() {
        $loginModel = new LoginModel;
        $user_info = $loginModel->get_column(['brl_wallet'],['user_id' => Session::get('user_id')]);
        return ['status' => 0, 'message' => 'ok', 'result' => $user_info['brl_wallet']];
    }

    /**
     * 支付
     */
    public function pay() {

        $post = input('post.');

        $money = 0;
        $paymentType = 3;

        if ($post['type'] == 'payment') {
            $aupayModel = new AupayModel;
            $giftInfo = $aupayModel->getPaymentList(intval($post['gift_id']));
            $money = intval($giftInfo['recharge_money']) * 100;
            if (empty($giftInfo['id'])) {
                return $this->_error('check','pay',10000);
            }
        }
        if ($post['type'] == 'vip') {
            $money = intval($post['money']) * 100;
            $paymentType = 4;
            $post['gift_id'] = 0;
        }

        $order_id = getOrderId();

        $header = [
            'Content-Type: application/json',
        ];

        $data = [
            "version" => "2.0.0",
            "memberid" => self::$memberid,
            "orderid" => $order_id,
            "amount" => $money,
            "orderdatetime" => date("Y-m-d H:i:s", time()),
            "paytype" => "1005",
            "notifyurl" => config('app_host').self::$payNotifyUrl,
            "signmethod" => 'md5',
        ];

        $data['sign'] = strtoupper(md5($this->ASCII($data).self::$md5Key));

        $depositResult = AupayModel::PostData(self::$paymentUrl, json_encode($data), $header);
        $depositResult = json_decode($depositResult,true);
        if ($depositResult['status'] == 'success') {
            try {
                Db::connect('db_YmManage')->table('paylog')->insert([
                        'uid' => Session::get('user_id'),
						'fee' => $data['amount'] / 100,
						'type' => $paymentType,
						'osn' => $data['orderid'],
						'createtime' => time(),
						'paytime' => time(),
                        'gift_id' =>intval($post['gift_id']),
						'status' => 0,
						'payresmsg' => '',
						'prepayresmsg' => json_encode($depositResult),
						'payendtime' => time(),
                ]);
                return ['status' => 0, 'message' => 'ok', 'result' => $depositResult];
            } catch(\Exception $e) {
                return ['status' => 1, 'message' => $e->getMessage(), 'result' => ''];
            }
        } else {
            return ['status' => 1, 'message' => $depositResult['msg'], 'result' => ''];
        }
        die;
    }

    public function callbackpay() {
        $body = json_decode(file_get_contents('php://input'),true);
        if ($body['status'] == 'success') {
            $oldSign = $body['sign'];
            unset($body['sign']);
            $newSign = strtoupper(md5($this->ASCII($body).self::$md5Key));
            if ($oldSign == $newSign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $body['orderid'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $body['orderid'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($body), 'payendtime' => time()]);
                    if ($paylog['type'] == 3) {
                        $amount = $body['amount'] / 100;
                        Db::table('users')->where('user_id', $paylog['uid'])->inc('brl_wallet', $amount)->update();
                        $activityCtrl = new Activity;
                        $activityCtrl->flowControl(2, $paylog['uid']);
                    }
                    if ($paylog['type'] == 4) {
                        $vipModel = new VipModel;
                        $vipModel->addUserVip($paylog['uid']);
                    }
                    die('OK');
                }
            }
        }
    }

    public function ASCII($params = array()){
        if(!empty($params)){
           $p =  ksort($params);
           if($p){
               $str = '';
               foreach ($params as $k=>$val){
                   $str .= $k .'=' . $val . '&';
               }
               $strs = rtrim($str, '&');
               return $strs;
           }
        }
        return '参数错误';
    }

    /**
     * 提现
     */
    public function withdrawalpay() {

        $post = input('post.');
        $userModel = new UserModel;
        $aupayModel = new AupayModel;
        $ShareStatisticsCtrl = new ShareStatistics;
        $gameUserModel = new GameUserModel;
        $vipModel = new VipModel;
        $vip_level = $vipModel->getUserVip(Session::get('user_id'));
        $vip_info  = $vipModel->getVipList($vip_level);
        $withdrawLimit = $aupayModel->getWithdrawLimit();

        // 验证 account_id 是否正确
        $userAccount = $userModel->getUserAccount($post['account_id'], Session::get('user_id'));
        if (empty($userAccount['id'])) {
            return $this->_error('check','pay',10005);
        }
        // 验证支付密码是否正确
        $userInfo = $userModel->getUser(Session::get('user_id'));
        if ($userInfo['withdrawal_password'] !== md5($post['pin_code'])) {
            return $this->_error('check','pay',10006);
        }
        // 验证提现金额是否够
        $amount = $userInfo['brl_wallet'];
        if ($post['money'] > $amount) {
            return $this->_error('check','pay',10000);
        }

        // 后台操作提现权限
        if ($userInfo['withdraw_status'] == 1) {
            
            // 是否超过了提现最小金额
            if ($post['money'] < $withdrawLimit['min_withdraw_money']) {
                return $this->_error('check','pay',10003);
            }
            // 是否属于充值用户 总充值金额
            $paymentMoney = $aupayModel->getPaymentUserList(Session::get('user_id'), 1, 'total', 'SUM(fee) as paymentMoney', 3)['paymentMoney'];
            // 验证充值金额 是否 大于平台限制
            if ($paymentMoney < $withdrawLimit['recharge']) {
                return ['status' => 1, 'message' => "Para a segurança de seus fundos, você precisa recargar uma soma de ({$withdrawLimit['recharge']}) real antes da primeira retirada para ativar sua conta de jogos. Prova que sua conta pessoal não foi registrada em grande parte, o que afeta o equilíbrio da plataforma. Obrigado.", 'result' => '', 'code' => 'window'];
            }
            // 总打码量
            $codingTotal = 0;
            if ($paymentMoney > 0) {
                $codingTotal += $withdrawLimit['payment'] * $paymentMoney;
            }
            // 赠送彩金
            $UserAllGiveWinnings = $ShareStatisticsCtrl->getUserAllGiveWinnings(Session::get('user_id'));
            if ($UserAllGiveWinnings > 0) {
                $codingTotal += $withdrawLimit['give'] * $UserAllGiveWinnings;
            }
            // 获取用户打码量
            $bettingCount = $ShareStatisticsCtrl->getUserBetMoenyNumberTotal(Session::get('user_id'))['betMoney'];
            if ($bettingCount < $codingTotal) {
                return ['status' => 2, 'message' => '', 'result' => ['brl_wallet' => $userModel->getUser(Session::get('user_id'))['brl_wallet'], 'coding_blanace' => $codingTotal - $bettingCount]];
            }

            // 下面都是VIP限制
            // 当前VIP等级 最高提现金额
            if (intval($post['money']) > $vip_info['withdraw_privilege_amount']) {
                return ['status' => 1, 'message' => "A retirada falhou, atualmente com o mais alto nível VIP para retirada {$vip_info['withdraw_privilege_amount']}.", 'result' => '', 'code' => 'window'];
            }

            // 当前VIP等级 月提现次数
            $begin_time = strtotime(date('Y-m-01 00:00:00'));
            $end_time = strtotime(date('Y-m-t 23:59:59'));
            $withdrawTotal = $aupayModel->getPaymentUserList(Session::get('user_id'), 1, 'total', 'COUNT(1) as withdrawTotal', 99, [$begin_time, $end_time])['withdrawTotal'];
            if ($vip_info['withdraw_privilege_number'] >= $withdrawTotal) {
                return ['status' => 1, 'message' => "O número de retiradas deste mês foi esgotado.", 'result' => '', 'code' => 'window'];
            }
        }

        $order_id = getOrderId();

        $data = [
            "version" => "2.0.0",
            "memberid" => self::$memberid,
            "orderid" => $order_id,
            "amount" => intval($post['money']) * 100,
            "orderdatetime" => date("Y-m-d H:i:s", time()),
            "currency" => 'brl',
            "notifyurl" => config('app_host').self::$withdrawNotifyUrl,
        ];



        // 检查是否有手续费, 如果有 扣除手续费再提现
        $commission = 0;
        // 如果当前VIP 没有免费提现权限 或者 提现次数大于0 
        if($vip_info['withdraw_privilege_free_number'] < 0 || $withdrawTotal > 0)  {
            // 提现手续费 是否大于 0
            if ($vip_info['withdraw_privilege_commission'] > 0) {
                $commission = $data['amount'] * ($vip_info['withdraw_privilege_commission'] / 100);
                $data['amount'] = intval($data['amount'] - $commission);
            }
        }

        // if ($withdrawLimitMoneyData['withdraw_commission'] > 0) {
        //     $commission = $data['amount'] * ($withdrawLimitMoneyData['withdraw_commission'] / 100);
        //     $data['amount'] = intval($data['amount'] - $commission);
        // }

        $dataSon = [
            "pixnumber" => $userAccount['account_number'],
            "pixtype" => $userAccount['account_type']
        ];

        $data['sign'] = strtoupper(md5(($this->ASCII($data).'&'.$this->ASCII($dataSon)).self::$md5Key));
        $data['data'] = $dataSon;

        Db::connect('db_YmManage')->table('user_exchange')->insert([
            'user_id' => Session::get('user_id'),
            'order_number' => $order_id ,
            'bank_number' => $data['data']['pixnumber'] ,
            'real_name' => '' ,
            'bank_open' => $data['data']['pixtype'] ,
            'money' => $data['amount'] / 100 ,
            'pay_type' => 'aupay',
            'commission_percentage' => $vip_info['withdraw_privilege_commission'],
            'commission' => $commission,
            'email' => '',
            'phone' => '',
            'status' => 0 ,
            'withdraw_code' => json_encode($data),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Db::table('users')->where('user_id', Session::get('user_id'))->dec('brl_wallet', intval($post['money']))->update();
        return $this->_success('check','success');
    }


    /**
     * 后台提现申请
     */
    public function adminwithdrawalpay() {
        $post = input('post.');
        $payInfo =  Db::connect('db_YmManage')->table('user_exchange')->where('id', $post['id'])->where('status', 0)->find();
        $withdraw_code = json_decode($payInfo['withdraw_code'],true);
        $header = ['Content-Type: application/json'];
        $withdrawResult = AupayModel::PostData(self::$payoutUrl, json_encode($withdraw_code), $header);
        $withdrawResult = json_decode($withdrawResult,true);
        if ($withdrawResult['status'] == '00') {
            Db::connect('db_YmManage')->table('paylog')->insert([
                'uid' => $payInfo['user_id'],
                'fee' => $payInfo['money'],
                'type' => 99,
                'osn' => $payInfo['order_number'],
                'createtime' => time(),
                'paytime' => time(),
                'status' => 0,
                'payresmsg' => '',
                'prepayresmsg' => json_encode($withdrawResult),
                'payendtime' => time(),
            ]);
            return ['status' => 0, 'message' => 'ok', 'result' => $withdrawResult];
        } else {
            return ['status' => 1, 'message' => $withdrawResult['msg'], 'result' => ''];
        }
    }

    public function callbackwithdrawalpay() {
        $body = json_decode(file_get_contents('php://input'),true);
        if ($body['status'] == '01' || $body['status'] == '00') {
            $oldSign = $body['sign'];
            unset($body['sign']);
            $newSign = strtoupper(md5($this->ASCII($body).self::$md5Key));
            if ($oldSign == $newSign) {
                $paylog = Db::connect('db_YmManage')->table('paylog')->where('osn', $body['userordernumber'])->find();
                if (!empty($paylog) && $paylog['callbacknum'] == 0) {
                    Db::connect('db_YmManage')->table('paylog')->where('osn', $body['userordernumber'])->update(['callbacknum' => $paylog['callbacknum'] + 1, 'status' => 1, 'payresmsg' => json_encode($body), 'payendtime' => time()]);
                    Db::connect('db_YmManage')->table('user_exchange')->where('order_number', $body['userordernumber'])->update(['status' => 1]);
                    die('SUCCESS');
                }
            }
        }
    }
}