<?php
namespace app\api\controller;
use think\Controller;
use think\Db;
use think\facade\Cookie;
use think\facade\Session;
use app\api\controller\Parents;
use app\api\model\AupayModel;
use app\api\controller\Aupay;
use app\api\model\VipModel;
use app\api\controller\ShareStatistics;

class Activity extends Parents
{
    // $type: 1 注册奖金 2 首充奖金 3 复充奖金 4 邀请注册奖金 5 宝箱充值奖金
    public function flowControl($type = 0, $user_id = 0) {
        $user_id = !empty($user_id) ? $user_id : Session::get('user_id');
        // 注册赠送奖金
        if ($type == 1) {
            $this->flowRegister($type, $user_id);
        }
        // 充值赠送奖金
        if ($type == 2) {
            $this->flowPayment($type, $user_id);
        }
        // 复充赠送奖金
        if ($type == 3) {
            $this->flowPayments($type, $user_id);
        }
        // 邀请注册送奖金
        if ($type == 4) {
            $this->flowInviteRegister($type, $user_id);
        }
    }

    // 宝箱充值领取接口
    public function givePaymentBox() {
        $box_id = input('post.box_id');
        $isBox = Db::table('system_activity_bonus_log')->where('user_id', Session::get('user_id'))->where('activity_type', 5)->where('box_id', $box_id)->count();
        if ($isBox > 0) {
            return ['status' => 1, 'message' => 'Você já reclamou o peito do tesouro.', 'result' => ''];
        }
        $vipModel = new VipModel;
        $boxInfo = $vipModel->getBoxList($box_id);
        $viteNumber = Db::table('admin_gameplatform_0020.users u')->join('ym_manage.paylog p','p.uid = u.user_id')->where('u.pid', Session::get('user_id'))->where('p.status', 1)->count();
        if ($viteNumber < $boxInfo['invite_number']) {
            return ['status' => 1, 'message' => 'Número insuficiente de convites.', 'result' => ''];
        }
        $this->addWallet(Session::get('user_id'), $boxInfo['box_money']);
        $this->addActivityLog(5, Session::get('user_id'), $boxInfo['box_money'], $box_id);
        return ['status' => 0, 'message' => 'Parabéns, vocês reclamaram com sucesso o peito do tesouro.', 'result' => ''];
    }

    // VIP宝箱领取接口
    public function giveVipBox() {
        $box_id = input('post.box_id');
        $isBox = Db::table('system_activity_bonus_log')->where('user_id', Session::get('user_id'))->where('activity_type', 6)->where('vip_box_id', $box_id)->count();
        if ($isBox > 0) {
            return ['status' => 1, 'message' => 'Você já reclamou o peito do tesouro.', 'result' => ''];
        }
        $vipModel = new VipModel;
        $boxInfo = $vipModel->getVipBoxList($box_id);
        $vip_level = $vipModel->getUserVip(Session::get('user_id'));
        if ($vip_level < $boxInfo['level']) {
            return ['status' => 1, 'message' => 'Nível insuficiente de VIP.', 'result' => ''];
        }
        $this->addWallet(Session::get('user_id'), $boxInfo['vip_box_money']);
        $this->addActivityLog(6, Session::get('user_id'), $boxInfo['vip_box_money'], 0, $box_id);
        return ['status' => 0, 'message' => 'Parabéns, vocês reclamaram com sucesso o peito do tesouro.', 'result' => ''];
    }

    // 注册赠送奖金
    public function flowRegister($type, $user_id) {
        $isRegisterBonus = Db::table('system_activity_bonus_log')->where('activity_type', $type)->where('user_id', $user_id)->count();
        if ($isRegisterBonus == 0) {
            $registerFee = Db::connect('db_YmManage')->table('activity_infomation_register')->value('register_money');
            $this->addWallet($user_id, $registerFee);
            $this->addActivityLog($type, $user_id, $registerFee);
        }
    }

    // 注册邀请送奖金
    public function flowInviteRegister($type, $user_id) {
        $pid = Db::table('users')->where('user_id', $user_id)->field('pid')->find()['pid'];
        if ($pid > 0) {
            $registerFee = Db::connect('db_YmManage')->table('activity_infomation_invite_register')->value('register_money');
            $this->addWallet($pid, $registerFee);
            $this->addActivityLog($type, $pid, $registerFee);
        }
    }

    // 充值赠送奖金
    public function flowPayment($type, $user_id) {
        // 获取当前用户充值次数
        $paymentTotal = Db::connect('db_YmManage')->table('paylog')->where('uid', $user_id)->where('type',3)->where('status',1)->count();
        if ($paymentTotal > 1) {
            // 复充
            $this->flowPayments(3, $user_id);
        } else {
            $gift_id = Db::connect('db_YmManage')->table('paylog')->where('uid', $user_id)->field('gift_id')->order('id','desc')->limit(1)->find()['gift_id'];
            if ($gift_id > 0) {
                $aupayModel = new AupayModel;
                $gift_money = $aupayModel->getPaymentList($gift_id)['gift_money'];
                $this->addWallet($user_id, $gift_money);
                $this->addActivityLog($type, $user_id, $gift_money);
            }
        }
    }

    // 复充赠送奖金
    public function flowPayments($type, $user_id) {
        $gift_id = Db::connect('db_YmManage')->table('paylog')->where('uid', $user_id)->field('gift_id')->order('id','desc')->limit(1)->find()['gift_id'];
        if ($gift_id > 0) {
            $aupayModel = new AupayModel;
            $gift_money = $aupayModel->getPaymentList($gift_id)['gift_money_s'];
            $this->addWallet($user_id, $gift_money);
            $this->addActivityLog($type, $user_id, $gift_money);
        }
    }

    // 增加金币
    public function addWallet($user_id, $amount) {
        return Db::table('users')->where('user_id', $user_id)->inc('brl_wallet', $amount)->update();
    }

    // 活动日志
    public function addActivityLog($type, $user_id, $amount, $box_id = 0, $vip_box_id = 0) {
        return Db::table('system_activity_bonus_log')->insert([
            'user_id' => $user_id,
            'activity_type' =>$type,
            'give_fee' => $amount,
            'box_id' => $box_id,
            'vip_box_id' =>$vip_box_id,
            'creatime_at' => time()
        ]);
    }

    // 前端展示用户日志
    public function viewLog() {
        $logName = input('post.logName');
        $params = input('post.params');
        $beginTime = strtotime(date('Y-m-d', time()));
        $endTime = strtotime(date('Y-m-d', time()). ' 23:59:59');
        $time = [
            'Today' => [$beginTime, $endTime],
            'Yesterday' => [$beginTime - 86399, $endTime - 86399],
            '7 Days' => [strtotime("-7 days", $beginTime), $endTime],
            '15 Days' => [strtotime("-15 days", $beginTime), $endTime],
            '30 Days' => [strtotime("-30 days", $beginTime), $endTime],
        ];

        // 支付/提现/彩金记录
        if ($logName == 'Statement') {
            $resultArr = [];
            $total = [
                'Deposit' => 0,
                'Withdraw' => 0,
            ];
            $aupayModel = new AupayModel;
            $paymentList = $aupayModel->getPaymentUserList(Session::get('user_id'), 1, 'list', '', 99, $time[$params[0]]);
            foreach ($paymentList as $k => $v) {
                $subArr = [];
                if ($params[1] == 'Member deposit' && $v['type'] == 3) {
                    $subArr = $v;
                    $subArr['viewType'] = 'Member deposit';
                    $total['Deposit'] += $v['fee'];
                } 
                if ($params[1] == 'Member withdrawal' && $v['type'] == 99) {
                    $subArr = $v;
                    $subArr['viewType'] = 'Member withdrawal';
                    $total['Withdraw'] += $v['fee'];
                } 
                if ($params[1] == 'All types') {
                    $subArr = $v;
                    if ($v['type'] == 3) {
                        $subArr['viewType'] = 'Member deposit';
                        $total['Deposit'] += $v['fee'];
                    }
                    if ($v['type'] == 99) {
                        $subArr['viewType'] = 'Member withdrawal';
                        $total['Withdraw'] += $v['fee'];
                    }
                }
                if (!empty($subArr)) {
                    $resultArr[] = [
                        'time' => date('Y-m-d H:i:s', $subArr['paytime']),
                        'viewType' => $subArr['viewType'],
                        'details' => 'Type Details',
                        'amount' => $subArr['fee'],
                    ];
                }
            }

            $shareStatisticsCtrl = new ShareStatistics;
            $bonusList = $shareStatisticsCtrl->getUserAllGiveWinningsList(Session::get('user_id'), $time[$params[0]]);
            foreach ($bonusList as $k => $v) {
                $subArr = [];
                if ($params[1] == 'Mission') {
                    $subArr = $v;
                    $subArr['viewType'] = 'Mission';
                }
                if ($params[1] == 'All types') {
                    $subArr = $v;
                    $subArr['viewType'] = 'Mission';
                }
                if (!empty($subArr)) {
                    $resultArr[] = [
                        'time' => date('Y-m-d H:i:s', $subArr['creatime_at']),
                        'viewType' => $subArr['viewType'],
                        'details' => 'Type Details',
                        'amount' => $subArr['give_fee'],
                    ];
                }
            }
            return ['status' => 0, 'result' => $resultArr, 'count' => count($resultArr), 'message' => 'ok', 'total' => $total];
        }

        if ($logName == 'BetRecords') {
            $shareStatisticsCtrl = new ShareStatistics;
            $userBetMoenyList = $shareStatisticsCtrl->getUserBetMoenyList(Session::get('user_id'), $time[$params[0]]);
            return ['status' => 0, 'result' => $userBetMoenyList, 'count' => count($userBetMoenyList), 'message' => 'ok'];
        }

        if ($logName == 'Report') {
            $shareStatisticsCtrl = new ShareStatistics;
            $userBetMoenyTotal = $shareStatisticsCtrl->getUserBetMoenyNumberTotal(Session::get('user_id'), $time[$params[0]]);
            return ['status' => 0, 'result' => $userBetMoenyTotal, 'message' => 'ok', 'count' => 1, 'time' => [date('Y-m-d H:i:s', $time[$params[0]][0]), date('Y-m-d H:i:s', $time[$params[0]][1])]];
        }

        die;
    }

    // 获取用户充值次数
    public function getUserPaymentNumber($user_id, $type = 'payment') {
        $sqlObj = Db::connect('db_YmManage')->table('paylog')->where('uid', $user_id)->where('status', 1);
        if ($type == 'payment') {
            $sqlObj->where('type',3);
        }
        if ($type == 'withdraw') {
            $sqlObj->where('type',99);
        }
        return $sqlObj->count();
    }

    // 前端展示弹窗图片
    public function viewAlertWindow() {
       $aupayCtrl = new Aupay;
       $result = Db::connect('db_YmManage')->table('alert_banner')->where('status', 0)->select();
       $arrImage = [];
       foreach ($result as $k => $v) {
            if ($v['type'] == 1) {
                $arrImage[] = $v;
            }
            if (!empty(Session::get('user_id'))) {
                if ($v['type'] == 2) {
                    if ($this->getUserPaymentNumber(Session::get('user_id'), 'payment') >= 1) {
                        $arrImage[] = $v;
                    }
                }
                if ($v['type'] == 3) {
                    if ($this->getUserPaymentNumber(Session::get('user_id'), 'payment') > 2) {
                        $arrImage[] = $v;
                    }
                }
                if ($v['type'] == 4) {
                    if ($this->getUserPaymentNumber(Session::get('user_id'), 'withdraw') > 0) {
                        $arrImage[] = $v;
                    }
                }
                if ($v['type'] == 5) {
                    if ($aupayCtrl->getAmount()['result'] < 5) {
                        $arrImage[] = $v;
                    }
                }
                if ($v['type'] == 6) {
                    if ($aupayCtrl->getAmount()['result'] > 100) {
                        $arrImage[] = $v;
                    }
                }
            }
       }
       foreach ($arrImage as $k => $v) {
            $arrImage[$k]['image'] = config('admin_static').$v['image'];
       }
       return $arrImage;
    }
}