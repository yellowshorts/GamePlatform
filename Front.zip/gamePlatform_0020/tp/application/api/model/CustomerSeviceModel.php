<?php
namespace app\api\model;
use think\Model;
use think\Db;

class CustomerSeviceModel extends Model {
    public function getCustomerSeviceList($cus = 1) {
        return Db::connect('db_YmManage')->table('kefu_list')->where('customer_type', 1)->where('isclose', 0)->select();
    }
}