<?php
namespace app\api\model;
use think\Model;
use think\Db;

class GameModel extends Model {

    public function getGameCount($plat_name = '', $game_type = '', $limit = 50, $searchtype = 'all') {
        $gameList = Db::table('game_list')->where('delete_at',0)->where('imageUrl', '<>', '')
                    ->join('game_type','game_type.gameType = game_list.gameType')
                    ->field('game_list.*, game_type.gameName_en');
        if (!empty($plat_name)) {
            if (!is_array($plat_name)) {
                $gameList->where('platType', $plat_name);
            } else {
                $sqlQuery = '';
                foreach ($plat_name as $k => $v) {
                    if ($k == 0) {
                        $sqlQuery .= "platType = '{$v}'";
                        continue;
                    }
                    $sqlQuery .= " OR platType = '{$v}'";
                }
                $gameList->where($sqlQuery);
            }
        }
        if (!empty($game_type)) {
            $gameList->where('game_list.gameType',$game_type);
        }
        if (!empty($game_id)) {
            $gameList->where('game_list.id', $game_id);
        }
        if ($searchtype == 'hot') {
            $gameList->where('is_hot', 1);
        }

        $res = $gameList->count();
        return ['page' => floor($gameList->count() / $limit), 'count' => $gameList->count()];
    }

    public function getGameList($plat_name = '', $game_type = '', $limit = 6, $game_id = '', $page = 1, $searchtype = 'all') {
        $gameList = Db::table('game_list')->where('delete_at',0)->where('imageUrl', '<>', '')
                    ->join('game_type','game_type.gameType = game_list.gameType')
                    ->field('game_list.*, game_type.gameName_en');
        if (!empty($plat_name)) {
            if (!is_array($plat_name)) {
                $gameList->where('platType', $plat_name);
            } else {
                $sqlQuery = '';
                foreach ($plat_name as $k => $v) {
                    if ($k == 0) {
                        $sqlQuery .= "platType = '{$v}'";
                        continue;
                    }
                    $sqlQuery .= " OR platType = '{$v}'";
                }
                $gameList->where($sqlQuery);
            }
        }
        if (!empty($game_type)) {
            $gameList->where('game_list.gameType',$game_type);
        }
        if (!empty($game_id)) {
            $gameList->where('game_list.id', $game_id);
        }
        if ($searchtype == 'hot') {
            $gameList->where('is_hot', 1);
        }
        if ($searchtype == 'recent') {
            $gameList->order('id', 'desc');
        } else {
            $gameList->order('sort','asc');
        }
        if ($page > 1) {
            $page = $limit * $page;
        } else {
            $page = $page - 1;
        }
        if ($limit > 0) {
            $gameList->limit($page,$limit);
        }
        $res = $gameList->select();
        foreach ($res as $k => $v) {
            $gameName = json_decode($v['gameName'],true);
            $imgUrl = json_decode($v['imageUrl'],true);
            $res[$k]['gameName'] = !isset($gameName['en']) ? $gameName['zh_hans'] : $gameName['en'];
            $res[$k]['imageUrl'] = '';
            if (!isset($imgUrl['en'])) {
                if (!isset($imgUrl['zh_hans']['square'])) {
                    $res[$k]['imageUrl'] = $imgUrl['zh_hans']['rectangle'];
                } else {
                    $res[$k]['imageUrl'] = $imgUrl['zh_hans']['square'];
                }
            } else {
                if (!isset($imgUrl['en']['square'])) {
                    $res[$k]['imageUrl'] = $imgUrl['en']['rectangle'];
                } else {
                    $res[$k]['imageUrl'] = $imgUrl['en']['square'];
                }
            }
        }
        if ($game_id) {
            return $res[0];
        }
        return $res;
    }
}