<?php
namespace app\api\model;
use think\Model;
use think\Db;

class GameUserModel extends Model {

    // 返回游戏用户ID
    public function getGameUser($playerId) {
        $Account = 'user'.$playerId;
        return Db::connect('db_GameAccount')->table('newuseraccounts')->where('Account', $Account)->find();
    }

    // 获取下注金额
    public function getBettingFeeCount($user_id) {
        return Db::connect('db_GameAccount')->table('mark')->where('userId', $user_id)->field('SUM(useCoin)')->value();
    }
}