<?php
namespace app\api\model;
use think\Model;
use think\Db;
use think\facade\Session;
use app\api\model\PlayerModel;
use app\api\model\AupayModel;

class VipModel extends Model {

    public function getBoxList($id = 0, $mergeUser = 0) {
        $sql = Db::connect('db_YmManage')->table('system_treasure_box')->where('delete_at',0);
        if ($mergeUser == 0) {
            if (!empty($id)) {
                return $sql->where('id', $id)->find();
            }
            return $sql->select();
        }
        $boxList = $sql->select();
        $userBoxList = Db::table('system_activity_bonus_log')->where('user_id', Session::get('user_id'))->where('activity_type', 5)->select();
        $playerModel = new PlayerModel;
        $userInviteNumber = $playerModel->getUserInviteNumber(Session::get('user_id'));
        // 是否满足需求
        foreach ($boxList as $k => $v) {
            if ($userInviteNumber > $v['invite_number']) {
                $boxList[$k]['is_box'] = 2;
            }
        } 
        // 是否已经领取
        foreach ($userBoxList as $k => $v) {
            foreach ($boxList as $key => $val) {
                if ($v['box_id'] == $val['id']) {
                    $boxList[$key]['is_box'] = 1;
                    continue 2;
                }
            }
        }
        return $boxList;
    }

    public function getVipBoxList($id = 0, $mergeUser = 0) {
        $sql = Db::table('vip_config')->where('status',0)->where('level', '>', 0)->order('level', 'asc');
        if ($mergeUser == 0) {
            if (!empty($id)) {
                return $sql->where('id', $id)->find();
            }
            return $sql->select();
        }
        $boxList = $sql->select();
        $userBoxList = Db::table('system_activity_bonus_log')->where('user_id', Session::get('user_id'))->where('activity_type', 6)->select();
        $vip_level = $this->getUserVip(Session::get('user_id'));
        // 是否满足需求
        foreach ($boxList as $k => $v) {
            if ($vip_level >= $v['level']) {
                $boxList[$k]['is_box'] = 2;
            }
        } 
        // 是否已经领取
        foreach ($userBoxList as $k => $v) {
            foreach ($boxList as $key => $val) {
                if ($v['vip_box_id'] == $val['id']) {
                    $boxList[$key]['is_box'] = 1;
                    continue 2;
                }
            }
        }
        return $boxList;
    }

    public function inviteNumberUpVipLevel($user_id) {
        $pid = Db::table('users')->where('user_id', $user_id)->field('pid')->find()['pid'];
        if ($pid > 0) {
           $vipUser = $this->viewVipPage($pid);
           if ($vipUser['invite_number'] == $vipUser['vip_info']['upwhere_invite_number'] && $vipUser['vip_level'] < $vipUser['max_vip']) {
                $this->addUserVip($pid);
           }
        }
    }

    public function viewVipPage($user_id) {

        // VIP最大等级
        $max_vip = 0;

        // 获取当前用户VIP等级
        $vip_level = $this->getUserVip($user_id);
        $vip_info  = '';

        // 获取下一级VIP升级条件
        $vip_list = $this->getVipList();
        foreach ($vip_list as $k => $v) {
            if ($v['level'] == $vip_level) {
                $vip_info = $v;
            }
            if ($v['level'] > $max_vip) {
                $max_vip = $v['level'];
            }
        }

        // 获取邀请人数
        $invite_number = $this->getUserLevelUp_invite($user_id);
        // 获取邀请人数百分比
        $invite_percentage = round(($invite_number / $vip_info['upwhere_invite_number']) * 100,2);
        
        // 总共充值VIP总额
        $aupayModel = new AupayModel;
        $vip_payment_total = $aupayModel->getPaymentUserAmountTotal($user_id, 4);

        // 充值百分比
        $payment_percentage = 0;

        if ($vip_level >= $max_vip) {
            $invite_percentage = 100;
            $payment_percentage = 100;
        }

        return ['status' => 0, 'message' => 'ok', 'result' => [
            'vip_level' => $vip_level,
            'vip_info' => $vip_info,
            'vip_list' => $vip_list,
            'invite_number' => $invite_number,
            'invite_percentage' => $invite_percentage,
            'payment_percentage' => $payment_percentage,
            'vip_payment_total' => $vip_payment_total,
            'max_vip' => $max_vip,
        ]];
    }

    public function getUserVip($user_id) {
        return Db::table('users')->where('user_id', $user_id)->value('vip_level');
    }

    public function addUserVip($user_id) {
        return Db::table('users')->where('user_id', $user_id)->setInc('vip_level');
    }

    public function getVipList($level = 99) {
        $sqlObj = Db::table('vip_config')->order('level', 'asc');
        if ($level != 99) {
            $sqlObj->where('level', $level);
            return $sqlObj->find();
        }
        return $sqlObj->select();
    }

    public function getUserLevelUp_invite($user_id) {
        return Db::table('users')->where('pid', $user_id)->count();
    }

}