<?php
namespace app\api\model;
use think\Model;
use think\Db;

class AupayModel extends Model {

    public function getPaymentList($id = 0) {
        $sqlObj = Db::connect('db_YmManage')->table('system_recharge_gift')->where('delete_at',0)->field('id,recharge_money,gift_money,recharge_money_s,gift_money_s');
        if ($id > 0) {
            $sqlObj->where('id', $id);
            return $sqlObj->find();
        } else {
            $sqlObj->limit(8)->order('recharge_money');
            return $sqlObj->select();
        }
    }

    public function getPaymentUserList($user_id = 0, $status = 99, $type = 'list', $expression = '', $pType = 100, $time = []) {
        $sqlObj = Db::connect('db_YmManage')->table('paylog');
        if (!empty($user_id)) {
            $sqlObj->where('uid', $user_id);
        }
        if ($status != 99) {
            $sqlObj->where('status', $status);
        }
        if ($pType < 100) {
            $sqlObj->where('type', $pType);
        }
        if (!empty($time)) {
            $sqlObj->where('paytime', 'between', $time);
        }
        if ($type == 'total') {
            return $sqlObj->field($expression)->find();
        }
        
        return $sqlObj->order('id','desc')->select();
    }

    public function getPaymentUserAmountTotal($user_id, $type) {
        return Db::table('ym_manage.paylog')->where('uid', $user_id)->where('status', 1)->where('type', $type)->field('SUM(fee) as amount')->find()['amount'];
    }

    // 获取提现限制
    public function getWithdrawLimit() {
        return json_decode(Db::connect('db_YmManage')->table('config')->where('flag','WITHDRAWALFLOWLIMIT')->find()['value'],true);
    }

    public static function PostData($url, $data, $header = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); // 设置URL
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  // 不验证证书
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);  // 不验证证书
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 是否显示头信息
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1); // 使用HTTP1.1
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST'); // 使用POST提交
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header); // 设置请求头信息
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // 请求数据
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
}