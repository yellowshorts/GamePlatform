<?php
namespace app\api\model;
use think\Model;
use think\Db;

class LoginModel extends Model {

    public function check_params($params = []) {
        return Db::table('users')->where($params)->count();
    }

    public function get_column($field = [], $where = []) {
        return Db::table('users')->field($field)->where($where)->find();
    }
}