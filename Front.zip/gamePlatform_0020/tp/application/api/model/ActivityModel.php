<?php
namespace app\api\model;
use think\Model;
use think\Db;

class ActivityModel extends Model {

    public function getBanner() {
        return Db::table('ym_manage.banner')->where('status', 0)->select();
    }

    public function getMarquee() {
        return Db::table('ym_manage.marquee')->where('status', 0)->select();
    }

}