<?php
namespace app\api\model;
use think\Model;
use think\Db;

class PlayerModel extends Model {

    public function searchPlayer($user_id = 0, $platType = '', $playerId = '') {
        $sql = Db::table('players');
        if (!empty($platType)) {
            $sql->where('platType', $platType);
        }
        if (!empty($user_id)) {
            $sql->where('user_id', $user_id);
        }
        if (!empty($playerId)) {
            $sql->where('playerId', $playerId);
        }
        return $sql->find();
    }

    // 获取用户邀请充值人数
    public function getUserInviteNumber($user_id) {
        return Db::table('users u')->join('ym_manage.paylog p', 'u.user_id = p.uid')->where('u.pid', $user_id)->where('p.type', 3)->where('p.status', 1)->count();
    }

    public function savePlayer($data) {
        return Db::table('players')->insert($data);
    }
}