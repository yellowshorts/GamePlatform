<?php
namespace app\api\model;
use think\Model;
use think\Db;

class RegisterModel extends Model {

    public function check_params($params = []) {
        return Db::table('users')->where($params)->count();
    }

    public function add_register($data) {
        unset($data['confirm_password']);
        return Db::table('users')->insertGetId($data);
    }
}