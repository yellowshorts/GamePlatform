<?php

// 生成串码
if(!function_exists('getOrderId')) {
    function getOrderId() {
	    mt_srand((double) microtime() * 1000000);
    	return date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
	}
}