<?php
return [
    // 统一参数不正确返回消息
    'check_params_10000' => 'parameter is incorrect.',
    'check_params_10001' => 'Token is invalid. Please refresh and resubmit.',
    // 账号注册 验证消息
    'check_register_10000' => 'Username already registered! Please choose another one.',
    'check_register_10001' => 'Email already registered! Please choose another one.',
    'check_register_10002' => 'Contact Number already registered! Please choose another one.',
    'check_register_10003' => 'The password and its confirmation do not match!',
    // 账户登录 验证消息
    'check_login_10000' => 'Your user ID or password is incorrect. Please try again.',
    'check_login_10001' => 'Login timeout, please log in again',
    // 钱包 验证消息
    'check_pay_10000' => 'Withdrawal failed due to insufficient wallet balance.',
    'check_pay_10001' => 'Withdrawal failed. Please select a bank number.',
    'check_pay_10002' => 'Withdrawal successful, please wait for customer service review.',
    'check_pay_10003' => 'Withdrawal failed, minimum withdrawal limit 10.',
    'check_pay_10004' => 'Withdrawal failed. Please enter your bank card number.',
    'check_pay_10005' => 'No wallet data found. Please fill in the wallet data.',
    'check_pay_10006' => 'Incorrect payment password.',
    // 代付账户信息
    'check_withdraw_10000' => 'CardNumber already exists, please replace it',
    'check_withdraw_10001' => 'Please enter cardnumber',
    'check_withdraw_10002' => 'The current account type or card number already exists, please replace it',
    // 成功
    'check_success_10000' => 'ok',
    // mysql报错
    'check_mysql_10000' => 'Registration failed. Please try again later!',
 ];