<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件

// 检测所有参数是否有值
if(!function_exists('check_params')) {
    function check_params($params, $checkparams = []) {
        if (!empty($checkparams)) {
            foreach ($checkparams as $v) {
                return isset($params[$v]) && !empty($params[$v]);
            }
        } else {
            foreach ($params as $k => $v) {
                return isset($params[$k]) && !empty($params[$k]);
            }
        }
    }
}

// 生成盐
if(!function_exists('generate_salt')) {
    function generate_salt() {
        $salt = '';
        for ($i = 0; $i < 8; $i++) {
            $salt .= chr(mt_rand(33, 126));
        }
        return $salt;
    }
}

if (!function_exists('__postJson')) {
    function __postJson ($url, $data, $header = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);  // 防止无限重定向
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); //返回重定向
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1); // 使用HTTP1.1
        // curl_setopt($ch, CURLOPT_PROXY, 'http://u1304229785329565:ItbzxNwlFFqj@185.165.190.32:36920');
        $response = curl_exec($ch);
		$err = curl_error($ch);
        curl_close($ch);
        if ($err) {
            return $err;
          }
        return $response;
     }
}

// 生成随机串
if(!function_exists('GetRandStr')) {
    function GetRandStr($length, $mode = 'all'){
        //字符组合
        if ($mode == 'str') {
            $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        } else {
            $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        }
        $len = strlen($str)-1;
        $randstr = '';
        for ($i=0;$i<$length;$i++) {
         $num=mt_rand(0,$len);
         $randstr .= $str[$num];
        }
        return $randstr;
    }
}
